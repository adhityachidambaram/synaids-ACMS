# I2I — Identity-to-Intake Reconciliation

A runnable demonstration platform for APAAR-linked student identity, enrolment, institution-reported totals and approval-aware intake checks.

## Important scope and limitations
- Independent demonstration platform, not an official AICTE service.
- Seeded institutions, students, approvals and APAAR-like values are fictional.
- A 12-digit APAAR format check is not official APAAR authentication. Live APAAR/ABC/DigiLocker access requires authorised credentials and approval.
- SMS defaults to demo mode. Demo OTPs are shown in the UI; no real SMS is sent. Live SMS requires a provider, credentials, sender/template registration and applicable Indian DLT setup.
- I2I Bot uses deterministic, permission-scoped application tools. No external LLM key is required.
- Offline capture uses browser IndexedDB. Central validation occurs only after sync.
- Seed approval rules are demonstration data, not universal AICTE policy.

## Requirements
Python 3.10+, pip and a modern browser. Node.js 20+ is needed only to build the React source separately.

## Run the integrated demo

### Windows
Run `start_windows.bat`.

### macOS / Linux
Run `./start.sh`.

Or manually:
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8000
```
Open http://127.0.0.1:8000. The SQLite database is created in `backend/data/`. The field-encryption key is stored in `backend/data/.field-key`; protect and back it up securely. Never commit it.

## Demo accounts
Password for all demo accounts: `I2I-Demo-2026!`

| Username | Role |
|---|---|
| aicte.admin | AICTE Administrator |
| aicte.officer | AICTE Officer |
| wit.admin | Institution Administrator |
| wit.uploader | Data Uploader |
| aicte.auditor | Auditor |
| verifier.demo | Authorised Verifier |

Local demo accounts only. Change/remove before deployment.

## Core demo scenario
1. Sign in as `aicte.officer`.
2. Add an active regular student to Western Institute of Technology / B.Tech Computer Science / 2026–27 with a new synthetic 12-digit APAAR value.
3. The seed scope starts with 120 active regular admissions, a reported total of 120 and configured regular intake of 120.
4. Adding a 121st regular admission triggers separate capacity and reported-total findings.
5. Change its category to `supernumerary` only as a demonstration of an explicitly configured additional allocation.
6. Update the institution-reported total to 121 through the API/report workflow and rerun checks.
7. The two corresponding discrepancies should clear; unrelated findings may remain open.

## API documentation
With the server running: `/docs` (Swagger), `/openapi.json`, `/api/health`.

## Configuration
Copy `.env.example` to `.env` and configure secrets before deployment. Never use demo secrets or demo accounts in production. Production requires PostgreSQL, HTTPS, managed secrets, persistent workers, private object storage, backups, deployment hardening and security review before real student data is processed.

## React source
The original Figma React source is retained in `figma_source/`. The connected React application source is in `frontend/`. In an environment with npm registry access:
```bash
cd frontend
npm install
npm run build
```
The preparation environment could not reach the npm registry, so a React production build could not be verified here. The integrated standalone interface is served by FastAPI for the runnable demo.

## Tests
```bash
cd backend
# Use a clean, isolated test database (delete it first if rerunning):
rm -f data/test_acceptance.db data/.field-key
PYTHONPATH=. DATABASE_URL=sqlite:///./data/test_acceptance.db APP_SECRET='test-only-secret-change-this' python -m pytest -q
```
On Windows PowerShell, set `$env:DATABASE_URL='sqlite:///./data/test_acceptance.db'` and `$env:APP_SECRET='test-only-secret-change-this'`, then run `python -m pytest -q` from `backend`. The acceptance test exercises login, upload, APAAR format handling, 120-to-121 reconciliation, corrections, verification, reports, I2I Bot, demo OTP, offline sync idempotency and the web UI route.
