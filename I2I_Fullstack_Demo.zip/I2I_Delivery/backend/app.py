from __future__ import annotations
import os, io, csv, json, uuid, hmac, hashlib, secrets, asyncio, threading, time, re
from datetime import datetime, timedelta, date
from pathlib import Path
from typing import Optional, Any
from dotenv import load_dotenv

import pandas as pd
import jwt
import httpx
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Header, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Integer, Boolean, DateTime, Date, ForeignKey, Text, JSON, Float, select, func, and_, or_
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session
from sqlalchemy.exc import IntegrityError
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from cryptography.fernet import Fernet, InvalidToken

BASE = Path(__file__).resolve().parent
load_dotenv(BASE.parent / ".env")
DATA_DIR = BASE / "data"
UPLOAD_DIR = BASE / "uploads"
DATA_DIR.mkdir(exist_ok=True); UPLOAD_DIR.mkdir(exist_ok=True)
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DATA_DIR / 'i2i.db'}")
CONNECT_ARGS = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=CONNECT_ARGS, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

SECRET_KEY = os.getenv("APP_SECRET", "CHANGE-ME-I2I-DEMO-SECRET-32-CHARS-MINIMUM")
FERNET_KEY = os.getenv("FIELD_ENCRYPTION_KEY", "")
if not FERNET_KEY:
    keyfile = DATA_DIR / ".field-key"
    if keyfile.exists(): FERNET_KEY = keyfile.read_text().strip()
    else:
        FERNET_KEY = Fernet.generate_key().decode(); keyfile.write_text(FERNET_KEY); os.chmod(keyfile, 0o600)
fernet = Fernet(FERNET_KEY.encode())
LOOKUP_KEY = os.getenv("APAAR_LOOKUP_KEY", SECRET_KEY).encode()
ph = PasswordHasher()

class Base(DeclarativeBase): pass

class Institution(Base):
    __tablename__ = "institutions"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    state: Mapped[str] = mapped_column(String(100), default="Tamil Nadu")
    district: Mapped[str] = mapped_column(String(100), default="Chennai")
    institution_type: Mapped[str] = mapped_column(String(80), default="Engineering")
    status: Mapped[str] = mapped_column(String(40), default="Active")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    email: Mapped[str] = mapped_column(String(180), unique=True)
    password_hash: Mapped[str] = mapped_column(String(300))
    role: Mapped[str] = mapped_column(String(60))
    institution_id: Mapped[Optional[str]] = mapped_column(ForeignKey("institutions.id"), nullable=True)
    phone_encrypted: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    phone_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    sms_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class SessionToken(Base):
    __tablename__ = "sessions"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Program(Base):
    __tablename__ = "programmes"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    code: Mapped[str] = mapped_column(String(40), index=True)
    institution_id: Mapped[str] = mapped_column(ForeignKey("institutions.id"), index=True)
    name: Mapped[str] = mapped_column(String(180))
    level: Mapped[str] = mapped_column(String(60), default="Undergraduate")
    cohort: Mapped[str] = mapped_column(String(20), index=True)
    status: Mapped[str] = mapped_column(String(40), default="Active")

class Approval(Base):
    __tablename__ = "approval_references"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    institution_id: Mapped[str] = mapped_column(ForeignKey("institutions.id"), index=True)
    programme_id: Mapped[str] = mapped_column(ForeignKey("programmes.id"), index=True)
    cohort: Mapped[str] = mapped_column(String(20), index=True)
    regular_intake: Mapped[int] = mapped_column(Integer)
    additional_capacity: Mapped[int] = mapped_column(Integer, default=0)
    reference: Mapped[str] = mapped_column(String(120))
    effective_from: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    effective_to: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="Approved")
    version: Mapped[int] = mapped_column(Integer, default=1)
    evidence_name: Mapped[Optional[str]] = mapped_column(String(240), nullable=True)
    created_by: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Student(Base):
    __tablename__ = "students"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    institutional_student_id: Mapped[str] = mapped_column(String(80), index=True)
    full_name: Mapped[str] = mapped_column(String(180), index=True)
    dob: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    apaar_encrypted: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    apaar_lookup: Mapped[Optional[str]] = mapped_column(String(64), index=True, nullable=True)
    identity_status: Mapped[str] = mapped_column(String(40), default="pending_apaar")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Enrolment(Base):
    __tablename__ = "enrolments"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    student_id: Mapped[str] = mapped_column(ForeignKey("students.id"), index=True)
    institution_id: Mapped[str] = mapped_column(ForeignKey("institutions.id"), index=True)
    programme_id: Mapped[str] = mapped_column(ForeignKey("programmes.id"), index=True)
    cohort: Mapped[str] = mapped_column(String(20), index=True)
    admission_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="active", index=True)
    admission_category: Mapped[str] = mapped_column(String(60), default="General")
    seat_category: Mapped[str] = mapped_column(String(60), default="regular", index=True)
    admission_reference: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    change_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class InstitutionReport(Base):
    __tablename__ = "institution_reports"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    institution_id: Mapped[str] = mapped_column(ForeignKey("institutions.id"), index=True)
    programme_id: Mapped[str] = mapped_column(ForeignKey("programmes.id"), index=True)
    cohort: Mapped[str] = mapped_column(String(20), index=True)
    reported_total: Mapped[int] = mapped_column(Integer)
    updated_by: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class UploadBatch(Base):
    __tablename__ = "upload_batches"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    institution_id: Mapped[str] = mapped_column(ForeignKey("institutions.id"), index=True)
    programme_id: Mapped[str] = mapped_column(ForeignKey("programmes.id"), index=True)
    cohort: Mapped[str] = mapped_column(String(20))
    filename: Mapped[str] = mapped_column(String(240))
    fingerprint: Mapped[str] = mapped_column(String(64), index=True)
    total_rows: Mapped[int] = mapped_column(Integer, default=0)
    accepted_rows: Mapped[int] = mapped_column(Integer, default=0)
    rejected_rows: Mapped[int] = mapped_column(Integer, default=0)
    warning_rows: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(40), default="received")
    result_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_by: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Finding(Base):
    __tablename__ = "findings"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    finding_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    fingerprint: Mapped[str] = mapped_column(String(64), index=True)
    finding_type: Mapped[str] = mapped_column(String(80), index=True)
    institution_id: Mapped[str] = mapped_column(ForeignKey("institutions.id"), index=True)
    programme_id: Mapped[str] = mapped_column(ForeignKey("programmes.id"), index=True)
    cohort: Mapped[str] = mapped_column(String(20), index=True)
    title: Mapped[str] = mapped_column(String(240))
    explanation: Mapped[str] = mapped_column(Text)
    expected_value: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    observed_value: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    difference: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    severity: Mapped[str] = mapped_column(String(30), default="medium")
    status: Mapped[str] = mapped_column(String(40), default="open", index=True)
    affected_records: Mapped[list] = mapped_column(JSON, default=list)
    evidence: Mapped[list] = mapped_column(JSON, default=list)
    required_action: Mapped[str] = mapped_column(Text, default="Review the affected records and provide supporting evidence.")
    reviewer_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    resolution_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

class FindingResponse(Base):
    __tablename__ = "finding_responses"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    finding_id: Mapped[str] = mapped_column(ForeignKey("findings.id"), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    response_text: Mapped[str] = mapped_column(Text)
    evidence_name: Mapped[Optional[str]] = mapped_column(String(240), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class RecordChange(Base):
    __tablename__ = "record_changes"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    enrolment_id: Mapped[str] = mapped_column(ForeignKey("enrolments.id"), index=True)
    record_version: Mapped[int] = mapped_column(Integer)
    change_type: Mapped[str] = mapped_column(String(60))
    before_state: Mapped[dict] = mapped_column(JSON, default=dict)
    after_state: Mapped[dict] = mapped_column(JSON, default=dict)
    actor_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    change_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class OutboxEvent(Base):
    __tablename__ = "outbox_events"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    operation_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    event_type: Mapped[str] = mapped_column(String(60))
    entity_id: Mapped[str] = mapped_column(String, index=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(30), default="pending", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    processed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

class ReconciliationRun(Base):
    __tablename__ = "reconciliation_runs"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    institution_id: Mapped[str] = mapped_column(ForeignKey("institutions.id"), index=True)
    programme_id: Mapped[str] = mapped_column(ForeignKey("programmes.id"), index=True)
    cohort: Mapped[str] = mapped_column(String(20), index=True)
    approval_id: Mapped[Optional[str]] = mapped_column(ForeignKey("approval_references.id"), nullable=True)
    student_level_total: Mapped[int] = mapped_column(Integer)
    active_regular: Mapped[int] = mapped_column(Integer)
    active_additional: Mapped[int] = mapped_column(Integer)
    reported_total: Mapped[int] = mapped_column(Integer)
    regular_intake: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    additional_capacity: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    difference: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(40))
    trigger_event_id: Mapped[Optional[str]] = mapped_column(ForeignKey("outbox_events.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class SyncOperation(Base):
    __tablename__ = "sync_operations"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    op_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    institution_id: Mapped[str] = mapped_column(ForeignKey("institutions.id"), index=True)
    op_type: Mapped[str] = mapped_column(String(40))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    record_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    base_server_version: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    local_version: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(30), default="pending")
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    synced_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

class VerificationRequest(Base):
    __tablename__ = "verification_requests"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    verification_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    requester_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    enrolment_id: Mapped[str] = mapped_column(ForeignKey("enrolments.id"))
    purpose: Mapped[str] = mapped_column(String(240))
    authorisation_reference: Mapped[str] = mapped_column(String(160))
    consent_confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    result_status: Mapped[str] = mapped_column(String(40), default="pending")
    response_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(60))
    title: Mapped[str] = mapped_column(String(240))
    body: Mapped[str] = mapped_column(Text)
    link: Mapped[Optional[str]] = mapped_column(String(240), nullable=True)
    read_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    sms_status: Mapped[str] = mapped_column(String(40), default="not_requested")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class OtpChallenge(Base):
    __tablename__ = "otp_challenges"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    otp_hash: Mapped[str] = mapped_column(String(64))
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    consumed: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class SmsLog(Base):
    __tablename__ = "sms_logs"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    phone_masked: Mapped[str] = mapped_column(String(40))
    message_type: Mapped[str] = mapped_column(String(60))
    provider_status: Mapped[str] = mapped_column(String(40))
    provider_reference: Mapped[Optional[str]] = mapped_column(String(160), nullable=True)
    detail: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AssistantMessage(Base):
    __tablename__ = "assistant_messages"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    conversation_id: Mapped[str] = mapped_column(String, index=True)
    role: Mapped[str] = mapped_column(String(20))
    content: Mapped[str] = mapped_column(Text)
    context: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)

# ---- Utilities and schemas ----
def encrypt_value(v: Optional[str]) -> Optional[str]: return fernet.encrypt(v.encode()).decode() if v else None
def decrypt_value(v: Optional[str]) -> Optional[str]:
    if not v: return None
    try: return fernet.decrypt(v.encode()).decode()
    except InvalidToken: return None
def apaar_hash(v: Optional[str]) -> Optional[str]: return hmac.new(LOOKUP_KEY, v.encode(), hashlib.sha256).hexdigest() if v else None
def mask_apaar(v: Optional[str]) -> str: return ("•••• •••• " + v[-4:]) if v else "Not provided"
def iso(v): return v.isoformat() if v else None
def user_dict(u: User):
    return {"id":u.id,"username":u.username,"full_name":u.full_name,"email":u.email,"role":u.role,"institution_id":u.institution_id,"phone_verified":u.phone_verified,"sms_enabled":u.sms_enabled}
def institution_dict(x): return {"id":x.id,"code":x.code,"name":x.name,"state":x.state,"district":x.district,"status":x.status}
def program_dict(x): return {"id":x.id,"code":x.code,"name":x.name,"institution_id":x.institution_id,"cohort":x.cohort,"level":x.level}
def approval_dict(x): return {"id":x.id,"institution_id":x.institution_id,"programme_id":x.programme_id,"cohort":x.cohort,"regular_intake":x.regular_intake,"additional_capacity":x.additional_capacity,"reference":x.reference,"status":x.status,"version":x.version,"evidence_name":x.evidence_name,"effective_from":iso(x.effective_from),"effective_to":iso(x.effective_to)}
def student_dict(db: Session, e: Enrolment):
    s=db.get(Student,e.student_id); i=db.get(Institution,e.institution_id); p=db.get(Program,e.programme_id)
    raw=decrypt_value(s.apaar_encrypted)
    return {"enrolment_id":e.id,"student_uuid":s.id,"institutional_student_id":s.institutional_student_id,"student_name":s.full_name,"dob":iso(s.dob),"apaar_id_masked":mask_apaar(raw),"apaar_format_status":s.identity_status,"has_apaar":bool(raw),"institution_id":e.institution_id,"institution":i.name if i else "","institution_code":i.code if i else "","programme_id":e.programme_id,"programme":p.name if p else "","programme_code":p.code if p else "","cohort":e.cohort,"admission_date":iso(e.admission_date),"enrolment_status":e.status,"admission_category":e.admission_category,"seat_category":e.seat_category,"version":e.version,"created_at":iso(e.created_at),"updated_at":iso(e.updated_at)}
def finding_dict(db: Session,f: Finding):
    i=db.get(Institution,f.institution_id); p=db.get(Program,f.programme_id)
    return {"id":f.id,"finding_code":f.finding_code,"finding_type":f.finding_type,"institution_id":f.institution_id,"institution":i.name if i else "","programme_id":f.programme_id,"programme":p.name if p else "","cohort":f.cohort,"title":f.title,"explanation":f.explanation,"expected_value":f.expected_value,"observed_value":f.observed_value,"difference":f.difference,"severity":f.severity,"status":f.status,"affected_records":f.affected_records,"evidence":f.evidence,"required_action":f.required_action,"reviewer_id":f.reviewer_id,"resolution_reason":f.resolution_reason,"created_at":iso(f.created_at),"updated_at":iso(f.updated_at),"resolved_at":iso(f.resolved_at)}

class InstitutionIn(BaseModel):
    code:str; name:str; state:str="Tamil Nadu"; district:str=""; institution_type:str="Engineering"
class ProgrammeIn(BaseModel):
    code:str; institution_id:str; name:str; level:str="Undergraduate"; cohort:str
class UserCreateIn(BaseModel):
    username:str; full_name:str; email:str; role:str; temporary_password:str=Field(min_length=12); institution_id:Optional[str]=None
class LoginIn(BaseModel): username: str; password: str
class StudentIn(BaseModel):
    institutional_student_id: str
    student_name: str
    apaar_id: Optional[str] = None
    dob: Optional[date] = None
    institution_id: str
    programme_id: str
    cohort: str
    admission_date: Optional[date] = None
    enrolment_status: str = "active"
    admission_category: str = "General"
    seat_category: str = "regular"
    admission_reference: Optional[str] = None
    change_reason: Optional[str] = "Record entered"
class StudentPatch(BaseModel):
    student_name: Optional[str]=None; apaar_id: Optional[str]=None; dob: Optional[date]=None
    enrolment_status: Optional[str]=None; admission_category: Optional[str]=None; seat_category: Optional[str]=None
    programme_id: Optional[str]=None; cohort: Optional[str]=None; admission_date: Optional[date]=None
    change_reason: str = "Record corrected"
class ApprovalIn(BaseModel): institution_id:str; programme_id:str; cohort:str; regular_intake:int=Field(ge=0); additional_capacity:int=Field(default=0,ge=0); reference:str; status:str="Pending review"; evidence_name:Optional[str]=None
class ReportIn(BaseModel): institution_id:str; programme_id:str; cohort:str; reported_total:int=Field(ge=0)
class FindingResponseIn(BaseModel): response_text:str; evidence_name:Optional[str]=None
class DecisionIn(BaseModel): decision:str; reason:str
class VerifyIn(BaseModel): enrolment_id:str; purpose:str; authorisation_reference:str; consent_confirmed:bool
class AssistantIn(BaseModel): message:str; conversation_id:Optional[str]=None; current_page:Optional[str]=None; context_type:Optional[str]=None; context_id:Optional[str]=None; institution_id:Optional[str]=None; programme_id:Optional[str]=None; cohort:Optional[str]=None; attachment_id:Optional[str]=None
class SyncOpIn(BaseModel): op_id:str; institution_id:str; op_type:str; payload:dict; record_id:Optional[str]=None; base_server_version:Optional[int]=None; local_version:int=1
class PhoneIn(BaseModel): phone:str
class OtpVerifyIn(BaseModel): challenge_id:str; otp:str

app=FastAPI(title="I2I API",version="1.0.0",description="Identity-to-Intake Reconciliation API — demonstration platform")
app.add_middleware(CORSMiddleware,allow_origins=os.getenv("CORS_ORIGINS","http://localhost:5173,http://127.0.0.1:5173").split(","),allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

def get_db():
    db=SessionLocal()
    try: yield db
    finally: db.close()

def get_current_user(authorization: Optional[str]=Header(default=None), db: Session=Depends(get_db)) -> User:
    if not authorization or not authorization.lower().startswith("bearer "): raise HTTPException(401,"Sign in required")
    token=authorization.split(" ",1)[1]
    digest=hashlib.sha256(token.encode()).hexdigest()
    sess=db.scalar(select(SessionToken).where(SessionToken.token_hash==digest))
    if not sess or sess.expires_at < datetime.utcnow(): raise HTTPException(401,"Session expired")
    user=db.get(User,sess.user_id)
    if not user or not user.is_active: raise HTTPException(401,"Account unavailable")
    return user

def require_roles(*roles):
    def dep(user:User=Depends(get_current_user)):
        if user.role not in roles: raise HTTPException(403,"Your role cannot perform this action")
        return user
    return dep

def scope_institution(user:User, requested:Optional[str]):
    if user.role in ["AICTE Administrator","AICTE Officer","Auditor"]: return requested
    if not user.institution_id: raise HTTPException(403,"No institution is assigned to this account")
    if requested and requested != user.institution_id: raise HTTPException(403,"Access is limited to your institution")
    return user.institution_id

def audit(db:Session, user:Optional[User], action:str, entity_type:str, entity_id:str, before=None, after=None):
    # Append-only application audit record; production should additionally use immutable/WORM storage.
    db.add(AuditLog(actor_id=user.id if user else None, actor_role=user.role if user else "system",action=action,entity_type=entity_type,entity_id=entity_id,before_state=before or {},after_state=after or {}))

class AuditLog(Base):
    __tablename__="audit_logs"
    id:Mapped[str]=mapped_column(String,primary_key=True,default=lambda:str(uuid.uuid4()))
    actor_id:Mapped[Optional[str]]=mapped_column(ForeignKey("users.id"),nullable=True)
    actor_role:Mapped[str]=mapped_column(String(60))
    action:Mapped[str]=mapped_column(String(100))
    entity_type:Mapped[str]=mapped_column(String(80))
    entity_id:Mapped[Optional[str]]=mapped_column(String(100),nullable=True)
    before_state:Mapped[dict]=mapped_column(JSON,default=dict)
    after_state:Mapped[dict]=mapped_column(JSON,default=dict)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
Base.metadata.create_all(engine)

ROLE_READ_ALL={"AICTE Administrator","AICTE Officer","Auditor"}

def add_notification(db:Session,user_id:str,event_type:str,title:str,body:str,link:Optional[str]=None):
    db.add(Notification(user_id=user_id,event_type=event_type,title=title,body=body,link=link))

def emit_event(db:Session,event_type:str,entity_id:str,payload:dict):
    op=str(uuid.uuid4()); e=OutboxEvent(operation_id=op,event_type=event_type,entity_id=entity_id,payload=payload)
    db.add(e); return e

def create_or_update_finding(db:Session, fingerprint:str, finding_type:str, institution_id:str, programme_id:str, cohort:str, title:str, explanation:str, expected=None, observed=None, difference=None, severity="medium", affected=None, evidence=None, action="Review the affected records and provide supporting evidence."):
    f=db.scalar(select(Finding).where(Finding.fingerprint==fingerprint))
    if f:
        new_expected=str(expected) if expected is not None else None
        new_observed=str(observed) if observed is not None else None
        materially_changed=(f.expected_value != new_expected or f.observed_value != new_observed or f.explanation != explanation)
        if f.status in ["resolved","dismissed"] and materially_changed:
            # A materially new condition reopens the existing finding; unchanged reviewed outcomes stay closed.
            f.status="open"; f.resolved_at=None; f.resolution_reason=None
        f.title=title; f.explanation=explanation; f.expected_value=new_expected; f.observed_value=new_observed
        f.difference=difference; f.severity=severity; f.affected_records=affected or []; f.evidence=evidence or []; f.required_action=action; f.updated_at=datetime.utcnow()
    else:
        code="I2I-"+secrets.token_hex(3).upper()
        f=Finding(finding_code=code,fingerprint=fingerprint,finding_type=finding_type,institution_id=institution_id,programme_id=programme_id,cohort=cohort,title=title,explanation=explanation,expected_value=str(expected) if expected is not None else None,observed_value=str(observed) if observed is not None else None,difference=difference,severity=severity,affected_records=affected or [],evidence=evidence or [],required_action=action)
        db.add(f)
    db.flush(); return f

def run_reconciliation(db:Session, institution_id:str, programme_id:str, cohort:str, trigger_event_id:Optional[str]=None):
    approval=db.scalar(select(Approval).where(Approval.institution_id==institution_id,Approval.programme_id==programme_id,Approval.cohort==cohort,Approval.status=="Approved").order_by(Approval.version.desc()))
    enrolments=list(db.scalars(select(Enrolment).where(Enrolment.institution_id==institution_id,Enrolment.programme_id==programme_id,Enrolment.cohort==cohort)))
    active=[e for e in enrolments if e.status.lower() in ["active","enrolled"]]
    regular=[e for e in active if e.seat_category.lower() in ["regular","general"]]
    # Only explicitly approved additional-capacity categories consume the configured
    # additional allocation. NRI/OCI/FN and other categories need their own applicable
    # approval rules; they must not be silently treated as extra seats.
    additional=[e for e in active if e.seat_category.lower() in ["supernumerary","additional","approved_additional"]]
    separately_reviewed=[e for e in active if e.seat_category.lower() not in ["regular","general","supernumerary","additional","approved_additional"]]
    report=db.scalar(select(InstitutionReport).where(InstitutionReport.institution_id==institution_id,InstitutionReport.programme_id==programme_id,InstitutionReport.cohort==cohort))
    reported=report.reported_total if report else 0
    affected=[{"enrolment_id":e.id,"institutional_student_id":db.get(Student,e.student_id).institutional_student_id} for e in active]
    if approval:
        prior_missing=db.scalar(select(Finding).where(Finding.fingerprint==f"approval-missing:{institution_id}:{programme_id}:{cohort}"))
        if prior_missing and prior_missing.status not in ["resolved","dismissed"]:
            prior_missing.status="resolved"; prior_missing.resolved_at=datetime.utcnow(); prior_missing.resolution_reason="An applicable approval reference is now configured"; prior_missing.updated_at=datetime.utcnow()
        if len(regular)>approval.regular_intake:
            create_or_update_finding(db,f"capacity:{institution_id}:{programme_id}:{cohort}","intake_capacity",institution_id,programme_id,cohort,"Regular admissions exceed configured approved intake",f"There are {len(regular)} active regular enrolment records, while approval {approval.reference} configures {approval.regular_intake}. This requires review; it is not automatically evidence of an unauthorised admission.",approval.regular_intake,len(regular),len(regular)-approval.regular_intake,"high",affected,[{"approval_reference":approval.reference,"approval_version":approval.version,"regular_intake":approval.regular_intake}],"Review regular allocation and provide applicable permission evidence or correct the affected records.")
        else:
            f=db.scalar(select(Finding).where(Finding.fingerprint==f"capacity:{institution_id}:{programme_id}:{cohort}"))
            if f and f.status not in ["resolved","dismissed"]: f.status="resolved"; f.resolved_at=datetime.utcnow(); f.resolution_reason="Condition no longer present after recalculation"; f.updated_at=datetime.utcnow()
        if len(additional)>approval.additional_capacity:
            create_or_update_finding(db,f"additional:{institution_id}:{programme_id}:{cohort}","additional_allocation",institution_id,programme_id,cohort,"Additional allocation exceeds configured permission",f"There are {len(additional)} active records in non-regular allocation categories. The configured additional capacity is {approval.additional_capacity}. Check applicable conditions and evidence.",approval.additional_capacity,len(additional),len(additional)-approval.additional_capacity,"high",affected,[{"approval_reference":approval.reference,"additional_capacity":approval.additional_capacity}],"Provide the applicable approval and student eligibility evidence.")
        else:
            f=db.scalar(select(Finding).where(Finding.fingerprint==f"additional:{institution_id}:{programme_id}:{cohort}"))
            if f and f.status not in ["resolved","dismissed"]: f.status="resolved"; f.resolved_at=datetime.utcnow(); f.resolution_reason="Condition no longer present after recalculation"; f.updated_at=datetime.utcnow()
    else:
        create_or_update_finding(db,f"approval-missing:{institution_id}:{programme_id}:{cohort}","approval_missing",institution_id,programme_id,cohort,"Applicable approval information is unavailable","I2I cannot determine the applicable intake limit because no approved reference is configured for this institution, programme and cohort. No capacity breach is asserted.",None,None,None,"medium",affected,[],"Add or review the authoritative approval reference before making a capacity determination.")
    if separately_reviewed:
        create_or_update_finding(db,f"seat-category-review:{institution_id}:{programme_id}:{cohort}","seat_category_review",institution_id,programme_id,cohort,"Seat categories need applicable rule review",f"{len(separately_reviewed)} active enrolment record(s) use categories that are not mapped to the configured regular or additional capacity rules. Categories such as NRI, OCI and foreign national must be assessed under their applicable approval conditions; they are not automatically counted as additional capacity.","Applicable category-specific approval rule","Unmapped category records",len(separately_reviewed),"medium",[{"enrolment_id":e.id,"seat_category":e.seat_category} for e in separately_reviewed],[{"categories":sorted({e.seat_category for e in separately_reviewed})}],"Configure the applicable category-specific approval rule or submit the relevant approval evidence for authorised review.")
    else:
        old=db.scalar(select(Finding).where(Finding.fingerprint==f"seat-category-review:{institution_id}:{programme_id}:{cohort}"))
        if old and old.status not in ["resolved","dismissed"]:
            old.status="resolved"; old.resolved_at=datetime.utcnow(); old.resolution_reason="All active seat categories are mapped or corrected"; old.updated_at=datetime.utcnow()
    if report:
        prior_report_missing=db.scalar(select(Finding).where(Finding.fingerprint==f"report-missing:{institution_id}:{programme_id}:{cohort}"))
        if prior_report_missing and prior_report_missing.status not in ["resolved","dismissed"]:
            prior_report_missing.status="resolved"; prior_report_missing.resolved_at=datetime.utcnow(); prior_report_missing.resolution_reason="An institution-reported total has been submitted"; prior_report_missing.updated_at=datetime.utcnow()
        if reported != len(active):
            create_or_update_finding(db,f"reported:{institution_id}:{programme_id}:{cohort}","reported_total_mismatch",institution_id,programme_id,cohort,"Student-level enrolment differs from institution-reported total",f"I2I counted {len(active)} active enrolment records in this exact scope, while the institution reported {reported}. Review the affected records and reporting period.",reported,len(active),len(active)-reported,"medium",affected,[{"reported_total":reported,"counted_active_records":len(active)}],"Review active/withdrawn statuses and update the institution-reported total if the roster is correct.")
        else:
            f=db.scalar(select(Finding).where(Finding.fingerprint==f"reported:{institution_id}:{programme_id}:{cohort}"))
            if f and f.status not in ["resolved","dismissed"]: f.status="resolved"; f.resolved_at=datetime.utcnow(); f.resolution_reason="Reported total now matches the active enrolment count"; f.updated_at=datetime.utcnow()
    else:
        create_or_update_finding(db,f"report-missing:{institution_id}:{programme_id}:{cohort}","reported_total_missing",institution_id,programme_id,cohort,"Institution-reported total is not configured","A student-level count exists, but no institution-reported total has been submitted for this scope.",None,len(active),None,"medium",affected,[],"Submit the institution-reported total for this programme and cohort.")
    # Identity completeness/format findings are separate from enrolment counting.
    for e in active:
        st=db.get(Student,e.student_id)
        if not st: continue
        if st.identity_status in ["pending_apaar", "invalid_format"]:
            kind="apaar_missing" if st.identity_status=="pending_apaar" else "apaar_invalid_format"
            title="APAAR ID is missing" if kind=="apaar_missing" else "APAAR ID format is invalid"
            explanation=("The student enrolment is retained and counted, but no APAAR identifier has been supplied. Add the identifier when available; do not use a placeholder.") if kind=="apaar_missing" else ("The supplied APAAR value does not match the expected 12-digit format. Correct the value or record the appropriate pending status. Format validation does not authenticate the identity.")
            create_or_update_finding(db,f"{kind}:{e.id}",kind,institution_id,programme_id,cohort,title,explanation,"12-digit value or pending status",st.identity_status,None,"medium",[{"enrolment_id":e.id,"institutional_student_id":st.institutional_student_id}],[{"identity_status":st.identity_status}],"Correct the APAAR value or retain the student as pending APAAR. The enrolment remains included in intake counts.")
        else:
            for kind in ["apaar_missing","apaar_invalid_format"]:
                old=db.scalar(select(Finding).where(Finding.fingerprint==f"{kind}:{e.id}"))
                if old and old.status not in ["resolved","dismissed"]:
                    old.status="resolved"; old.resolved_at=datetime.utcnow(); old.resolution_reason="Identity information was updated and rechecked"; old.updated_at=datetime.utcnow()
    # Duplicate identity review: repeated APAAR lookup among active enrolment records in scope.
    by_hash={}
    for e in active:
        s=db.get(Student,e.student_id)
        if s and s.apaar_lookup: by_hash.setdefault(s.apaar_lookup,[]).append((s,e))
    for hv, rows in by_hash.items():
        if len(rows)>1:
            codes=[x[0].institutional_student_id for x in rows]
            create_or_update_finding(db,f"duplicate:{institution_id}:{programme_id}:{cohort}:{hv}","duplicate_apaar","".join([]) or institution_id,programme_id,cohort,"Repeated APAAR reference requires review",f"The same protected APAAR lookup reference appears in {len(rows)} active records in this scope. This may be a duplicate submission or another explainable enrolment situation; investigate before any merge or deletion.","One expected identity association",f"{len(rows)} matching records",len(rows)-1,"high",[{"enrolment_id":e.id,"institutional_student_id":s.institutional_student_id} for s,e in rows],[{"match":"Exact protected APAAR lookup match","records":codes}],"Compare the records, dates and statuses; record an authorised review decision.")
    # Cross-institution possible duplicates for the same identity hash.
    student_hashes={s.apaar_lookup for e in active if (s:=db.get(Student,e.student_id)) and s.apaar_lookup}
    for hv in student_hashes:
        matches=list(db.scalars(select(Enrolment).join(Student,Student.id==Enrolment.student_id).where(Student.apaar_lookup==hv,Enrolment.status.in_(["active","enrolled"]))))
        insts={x.institution_id for x in matches}
        if len(insts)>1:
            ids=[{"enrolment_id":e.id,"institution_id":e.institution_id,"programme_id":e.programme_id,"cohort":e.cohort} for e in matches]
            for inst_id in insts:
                local_match=next((m for m in matches if m.institution_id==inst_id), None)
                if not local_match: continue
                create_or_update_finding(db,f"cross-duplicate:{hv}:{inst_id}","cross_institution_overlap",inst_id,local_match.programme_id,local_match.cohort,"Potential cross-institution enrolment overlap",f"The protected APAAR lookup matches active enrolment records across {len(insts)} institutions. This is a potential conflict requiring authorised review, not proof of prohibited simultaneous enrolment.","Review identity and enrolment history",f"{len(matches)} active enrolment records",None,"high",ids,[{"match":"Exact protected APAAR lookup","institution_count":len(insts)}],"Review transfer, withdrawal, historical and concurrent enrolment context before deciding.")
    # Close prior within-scope duplicate findings whose matching rows no longer coexist.
    active_hashes={hv for hv, rows in by_hash.items() if len(rows)>1}
    for old in db.scalars(select(Finding).where(Finding.institution_id==institution_id,Finding.programme_id==programme_id,Finding.cohort==cohort,Finding.finding_type=="duplicate_apaar")).all():
        marker=old.fingerprint.split(":")[-1]
        if marker not in active_hashes and old.status not in ["resolved","dismissed"]:
            old.status="resolved"; old.resolved_at=datetime.utcnow(); old.resolution_reason="Repeated active identity reference is no longer present after rechecking"; old.updated_at=datetime.utcnow()
    result_status="consistent"
    current=db.scalars(select(Finding).where(Finding.institution_id==institution_id,Finding.programme_id==programme_id,Finding.cohort==cohort,Finding.status.in_(["open","needs_information","under_review","institution_response_submitted","escalated"]))).all()
    if current: result_status="needs_review"
    run=ReconciliationRun(institution_id=institution_id,programme_id=programme_id,cohort=cohort,approval_id=approval.id if approval else None,student_level_total=len(active),active_regular=len(regular),active_additional=len(additional),reported_total=reported,regular_intake=approval.regular_intake if approval else None,additional_capacity=approval.additional_capacity if approval else None,difference=len(active)-reported,status=result_status,trigger_event_id=trigger_event_id)
    db.add(run); db.flush()
    return run

def process_event(event_id:str):
    db=SessionLocal()
    try:
        ev=db.get(OutboxEvent,event_id)
        if not ev or ev.status=="processed": return
        ev.attempts += 1
        try:
            e=db.get(Enrolment,ev.entity_id)
            if e:
                old_scope=ev.payload.get("old_scope") if isinstance(ev.payload,dict) else None
                if old_scope and old_scope.get("institution_id") and old_scope.get("programme_id") and old_scope.get("cohort"):
                    run_reconciliation(db,old_scope["institution_id"],old_scope["programme_id"],old_scope["cohort"],ev.id)
                run_reconciliation(db,e.institution_id,e.programme_id,e.cohort,ev.id)
                # Notify officers and institution admins if new open findings exist in scope.
                users=db.scalars(select(User).where(User.is_active==True)).all()
                open_findings=db.scalars(select(Finding).where(Finding.institution_id==e.institution_id,Finding.programme_id==e.programme_id,Finding.cohort==e.cohort,Finding.status.in_(["open","needs_information"]))).all()
                for f in open_findings:
                    for u in users:
                        if u.role in ["AICTE Administrator","AICTE Officer"] or u.institution_id==e.institution_id:
                            exists=db.scalar(select(Notification).where(Notification.user_id==u.id,Notification.event_type=="finding_update",Notification.link==f"/findings/{f.id}"))
                            if not exists:
                                n=Notification(user_id=u.id,event_type="finding_update",title=f.title,body=f.finding_code+" · "+f.explanation[:150],link=f"/findings/{f.id}")
                                db.add(n)
                                if u.sms_enabled and u.phone_verified and u.phone_encrypted:
                                    phone=decrypt_value(u.phone_encrypted)
                                    sms_status,provider_ref,detail=send_sms_gateway(phone,f"I2I: A finding requires your attention ({f.finding_code}). Sign in to the I2I portal to review it.")
                                    n.sms_status=sms_status
                                    db.add(SmsLog(user_id=u.id,phone_masked=mask_phone(phone),message_type="finding_alert",provider_status=sms_status,provider_reference=provider_ref,detail=detail))
            ev.status="processed"; ev.processed_at=datetime.utcnow(); ev.last_error=None; db.commit()
        except Exception as ex:
            db.rollback(); ev=db.get(OutboxEvent,event_id); ev.status="failed" if ev.attempts>=5 else "pending"; ev.last_error=str(ex)[:1000]; db.commit()
    finally: db.close()

def process_pending_events(limit=25):
    db=SessionLocal()
    try: ids=[x.id for x in db.scalars(select(OutboxEvent).where(OutboxEvent.status=="pending").order_by(OutboxEvent.created_at).limit(limit)).all()]
    finally: db.close()
    for eid in ids: process_event(eid)

@app.on_event("startup")
def startup(): seed_database()

def seed_database():
    db=SessionLocal()
    try:
        if db.scalar(select(func.count(User.id)))>0:
            # Keep the verifier demo account scoped to the primary fictional institution.
            primary=db.scalar(select(Institution).where(Institution.code=="WIT001"))
            verifier=db.scalar(select(User).where(User.username=="verifier.demo"))
            if primary and verifier and verifier.institution_id is None:
                verifier.institution_id=primary.id; db.commit()
            return
        inst=Institution(code="WIT001",name="Western Institute of Technology",state="Tamil Nadu",district="Chennai")
        inst2=Institution(code="EIT002",name="Eastern Institute of Technology",state="Karnataka",district="Bengaluru")
        db.add_all([inst,inst2]); db.flush()
        p=Program(code="BTECH-CSE",institution_id=inst.id,name="B.Tech · Computer Science",level="Undergraduate",cohort="2026–27")
        p2=Program(code="BTECH-CIVIL",institution_id=inst.id,name="B.Tech · Civil Engineering",level="Undergraduate",cohort="2026–27")
        p3=Program(code="BTECH-CSE-E",institution_id=inst2.id,name="B.Tech · Computer Science",level="Undergraduate",cohort="2026–27")
        db.add_all([p,p2,p3]); db.flush()
        approval=Approval(institution_id=inst.id,programme_id=p.id,cohort="2026–27",regular_intake=120,additional_capacity=6,reference="DEMO-APR-WIT-CSE-2026",status="Approved",version=1)
        approval2=Approval(institution_id=inst.id,programme_id=p2.id,cohort="2026–27",regular_intake=60,additional_capacity=0,reference="DEMO-APR-WIT-CIVIL-2026",status="Approved")
        approval3=Approval(institution_id=inst2.id,programme_id=p3.id,cohort="2026–27",regular_intake=90,additional_capacity=0,reference="DEMO-APR-EIT-CSE-2026",status="Approved")
        db.add_all([approval,approval2,approval3]); db.flush()
        roles=[
          ("aicte.admin","admin.demo@example.test","Demo Administrator","AICTE Administrator",None),
          ("aicte.officer","officer.demo@example.test","Ananya Menon","AICTE Officer",None),
          ("wit.admin","admin.wit@example.test","Western Institute Administrator","Institution Administrator",inst.id),
          ("wit.uploader","uploader.wit@example.test","Western Institute Uploader","Data Uploader",inst.id),
          ("aicte.auditor","auditor.demo@example.test","Demo Auditor","Auditor",None),
          ("verifier.demo","verifier.demo@example.test","External Verifier","Authorised Verifier",inst.id),
        ]
        for uname,email,name,role,iid in roles: db.add(User(username=uname,email=email,full_name=name,password_hash=ph.hash("I2I-Demo-2026!"),role=role,institution_id=iid))
        db.flush()
        # 120 synthetic, format-valid APAAR identifiers in the primary programme.
        firsts=["Aarav","Diya","Kabir","Meera","Rohan","Ishaan","Anika","Vihaan","Saanvi","Arjun","Kavya","Reyansh"]
        lasts=["Mehta","Nair","Sharma","Iyer","Das","Sen","Rao","Patel","Kapoor","Menon"]
        for idx in range(1,121):
            sid=f"WIT26-{idx:04d}"; name=f"{firsts[(idx-1)%len(firsts)]} {lasts[(idx-1)%len(lasts)]}"
            ap=f"202600{idx:06d}" # 12 digits
            s=Student(institutional_student_id=sid,full_name=name,dob=date(2006+(idx%2),1+(idx%12),1+(idx%27)),apaar_encrypted=encrypt_value(ap),apaar_lookup=apaar_hash(ap),identity_status="format_valid")
            db.add(s); db.flush()
            db.add(Enrolment(student_id=s.id,institution_id=inst.id,programme_id=p.id,cohort="2026–27",admission_date=date(2026,6,1),status="active",seat_category="regular",admission_category="General",admission_reference=f"WIT-ADM-{idx:04d}"))
        # Additional sample records in another scope, including a pending APAAR record and a duplicate identity within scope.
        for idx in range(1,7):
            s=Student(institutional_student_id=f"WIT-CIV-{idx:03d}",full_name=f"Sample Civil Student {idx}",dob=date(2005,4,idx),apaar_encrypted=None,apaar_lookup=None,identity_status="pending_apaar")
            db.add(s); db.flush(); db.add(Enrolment(student_id=s.id,institution_id=inst.id,programme_id=p2.id,cohort="2026–27",admission_date=date(2026,6,2),status="active",seat_category="regular"))
        db.add_all([InstitutionReport(institution_id=inst.id,programme_id=p.id,cohort="2026–27",reported_total=120),InstitutionReport(institution_id=inst.id,programme_id=p2.id,cohort="2026–27",reported_total=6),InstitutionReport(institution_id=inst2.id,programme_id=p3.id,cohort="2026–27",reported_total=0)])
        audit(db,None,"seed_demo_data","system","initial",{}, {"synthetic_students":126})
        db.commit()
        # Initial reconciliation snapshots for seeded scopes.
        for pp in [p,p2,p3]:
            run_reconciliation(db,pp.institution_id,pp.id,pp.cohort)
        db.commit()
    finally: db.close()

@app.get("/api/health")
def health(): return {"status":"ok","service":"I2I API","demo_mode":os.getenv("APP_ENV","demo")!="production","timestamp":datetime.utcnow().isoformat()}

@app.post("/api/auth/login")
def login(body:LoginIn,db:Session=Depends(get_db)):
    u=db.scalar(select(User).where(User.username==body.username))
    if not u or not u.is_active:
        raise HTTPException(401,"Invalid username or password")
    try: ph.verify(u.password_hash,body.password)
    except VerifyMismatchError: raise HTTPException(401,"Invalid username or password")
    token=secrets.token_urlsafe(42); digest=hashlib.sha256(token.encode()).hexdigest()
    db.add(SessionToken(user_id=u.id,token_hash=digest,expires_at=datetime.utcnow()+timedelta(hours=10)))
    audit(db,u,"login","user",u.id); db.commit()
    return {"access_token":token,"token_type":"bearer","user":user_dict(u)}

@app.get("/api/auth/me")
def me(user:User=Depends(get_current_user)): return {"user":user_dict(user)}
@app.post("/api/auth/logout")
def logout(authorization:Optional[str]=Header(default=None),db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    token=authorization.split(" ",1)[1]; digest=hashlib.sha256(token.encode()).hexdigest(); s=db.scalar(select(SessionToken).where(SessionToken.token_hash==digest));
    if s: db.delete(s); audit(db,user,"logout","user",user.id); db.commit()
    return {"ok":True}

@app.get("/api/bootstrap")
def bootstrap(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    inst_id=scope_institution(user,None)
    insts=db.scalars(select(Institution).where(Institution.id==inst_id) if inst_id else select(Institution)).all()
    programs=db.scalars(select(Program).where(Program.institution_id==inst_id) if inst_id else select(Program)).all()
    return {"user":user_dict(user),"institutions":[institution_dict(x) for x in insts],"programmes":[program_dict(x) for x in programs],"demo_mode":True,"api_capabilities":{"apaar_live":"not_configured","sms_mode":os.getenv("SMS_MODE","demo")}}

@app.get("/api/dashboard")
def dashboard(institution_id:Optional[str]=None,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,institution_id)
    instq=select(func.count(Institution.id)); studq=select(func.count(Student.id)); enq=select(func.count(Enrolment.id)).where(Enrolment.status.in_(["active","enrolled"]))
    fq=select(func.count(Finding.id)).where(Finding.status.in_(["open","needs_information","under_review","institution_response_submitted","escalated"]))
    dq=select(func.count(Finding.id)).where(Finding.finding_type.in_(["duplicate_apaar","cross_institution_overlap"]),Finding.status.notin_(["resolved","dismissed"]))
    iq=select(func.count(Finding.id)).where(Finding.finding_type.in_(["intake_capacity","additional_allocation"]),Finding.status.notin_(["resolved","dismissed"]))
    if iid:
        instq=instq.where(Institution.id==iid); studq=studq.join(Enrolment,Enrolment.student_id==Student.id).where(Enrolment.institution_id==iid); enq=enq.where(Enrolment.institution_id==iid); fq=fq.where(Finding.institution_id==iid); dq=dq.where(Finding.institution_id==iid); iq=iq.where(Finding.institution_id==iid)
    pending=select(func.count(Student.id)).where(Student.identity_status=="pending_apaar")
    if iid: pending=pending.join(Enrolment,Enrolment.student_id==Student.id).where(Enrolment.institution_id==iid)
    metrics={"institutions":db.scalar(instq) or 0,"student_records":db.scalar(studq) or 0,"active_enrolments":db.scalar(enq) or 0,"pending_apaar":db.scalar(pending) or 0,"open_findings":db.scalar(fq) or 0,"potential_duplicates":db.scalar(dq) or 0,"intake_discrepancies":db.scalar(iq) or 0}
    insts=db.scalars(select(Institution).where(Institution.id==iid) if iid else select(Institution)).all()
    fs=db.scalars(select(Finding).where(Finding.status.notin_(["resolved","dismissed"]), Finding.institution_id==iid if iid else True).order_by(Finding.created_at.desc()).limit(8)).all()
    recent=db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(8)).all()
    instrows=[]
    for inst in insts if not iid else [db.get(Institution,iid)]:
        if not inst: continue
        enrols=db.scalars(select(Enrolment).where(Enrolment.institution_id==inst.id,Enrolment.status.in_(["active","enrolled"]))).all()
        openf=db.scalar(select(func.count(Finding.id)).where(Finding.institution_id==inst.id,Finding.status.notin_(["resolved","dismissed"]))) or 0
        instrows.append({"id":inst.id,"code":inst.code,"name":inst.name,"records":len(enrols),"findings":openf,"state":inst.state})
    return {"metrics":metrics,"priority_findings":[finding_dict(db,f) for f in fs],"institutions":instrows,"recent_activity":[{"action":a.action,"entity_type":a.entity_type,"entity_id":a.entity_id,"actor_role":a.actor_role,"created_at":iso(a.created_at)} for a in recent]}

@app.get("/api/institutions")
def get_institutions(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,None); xs=db.scalars(select(Institution).where(Institution.id==iid) if iid else select(Institution)).all(); return [institution_dict(x) for x in xs]
@app.get("/api/programmes")
def get_programmes(institution_id:Optional[str]=None,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,institution_id); xs=db.scalars(select(Program).where(Program.institution_id==iid) if iid else select(Program)).all(); return [program_dict(x) for x in xs]

@app.post("/api/institutions")
def create_institution(body:InstitutionIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role!="AICTE Administrator": raise HTTPException(403,"Only AICTE administrators can onboard institutions")
    code=body.code.strip().upper()
    if db.scalar(select(Institution).where(Institution.code==code)): raise HTTPException(409,"Institution code already exists")
    x=Institution(code=code,name=body.name.strip(),state=body.state.strip(),district=body.district.strip(),institution_type=body.institution_type.strip())
    db.add(x); db.flush(); audit(db,user,"create_institution","institution",x.id,{},institution_dict(x)); db.commit(); return institution_dict(x)
@app.post("/api/programmes")
def create_programme(body:ProgrammeIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role!="AICTE Administrator": raise HTTPException(403,"Only AICTE administrators can configure programmes")
    inst=db.get(Institution,body.institution_id)
    if not inst: raise HTTPException(404,"Institution not found")
    x=Program(code=body.code.strip().upper(),institution_id=body.institution_id,name=body.name.strip(),level=body.level.strip(),cohort=body.cohort.strip())
    db.add(x); db.flush(); audit(db,user,"create_programme","programme",x.id,{},program_dict(x)); db.commit(); return program_dict(x)

@app.get("/api/students")
def get_students(q:Optional[str]=None,status:Optional[str]=None,institution_id:Optional[str]=None,programme_id:Optional[str]=None,page:int=1,page_size:int=25,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,institution_id); stmt=select(Enrolment)
    if iid: stmt=stmt.where(Enrolment.institution_id==iid)
    if programme_id: stmt=stmt.where(Enrolment.programme_id==programme_id)
    if status: stmt=stmt.where(Enrolment.status==status)
    rows=db.scalars(stmt.order_by(Enrolment.created_at.desc())).all(); out=[]
    for e in rows:
        item=student_dict(db,e); s=db.get(Student,e.student_id)
        if q and q.lower() not in " ".join([item["student_name"],item["institutional_student_id"],item["apaar_id_masked"],item["programme"]]).lower(): continue
        item["apaar_format_status"]=s.identity_status
        out.append(item)
    total=len(out); start=max(0,(page-1)*min(max(page_size,1),100)); return {"items":out[start:start+min(max(page_size,1),100)],"total":total,"page":page,"page_size":page_size}

@app.get("/api/students/{enrolment_id}")
def get_student(enrolment_id:str,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    e=db.get(Enrolment,enrolment_id)
    if not e: raise HTTPException(404,"Enrolment not found")
    scope_institution(user,e.institution_id)
    s=db.get(Student,e.student_id); item=student_dict(db,e)
    item["apaar_id"]=decrypt_value(s.apaar_encrypted) if user.role in ["AICTE Administrator","AICTE Officer","Institution Administrator"] else None
    item["identity_status"]=s.identity_status
    hist=db.scalars(select(RecordChange).where(RecordChange.enrolment_id==e.id).order_by(RecordChange.created_at.desc())).all()
    item["history"]=[{"change_type":h.change_type,"version":h.record_version,"before":h.before_state,"after":h.after_state,"reason":h.change_reason,"created_at":iso(h.created_at)} for h in hist]
    return item

def check_apaar(value:Optional[str]):
    if not value: return "pending_apaar"
    return "format_valid" if re.fullmatch(r"\d{12}",value) else "invalid_format"

def ensure_institution_program(db,user,inst_id,prog_id,cohort):
    scope_institution(user,inst_id)
    prog=db.get(Program,prog_id)
    if not prog or prog.institution_id!=inst_id or prog.cohort!=cohort: raise HTTPException(400,"Programme does not match the selected institution and cohort")

def create_enrolment(db:Session,body:StudentIn,user:User,source="web",commit_now=True):
    ensure_institution_program(db,user,body.institution_id,body.programme_id,body.cohort)
    ap=body.apaar_id.strip() if body.apaar_id else None
    ident=check_apaar(ap)
    # Each uploaded row remains a distinct enrolment. Identity duplicates are flagged later, not merged.
    s=Student(institutional_student_id=body.institutional_student_id,full_name=body.student_name,dob=body.dob,apaar_encrypted=encrypt_value(ap),apaar_lookup=apaar_hash(ap) if ident=="format_valid" else None,identity_status=ident)
    db.add(s); db.flush()
    e=Enrolment(student_id=s.id,institution_id=body.institution_id,programme_id=body.programme_id,cohort=body.cohort,admission_date=body.admission_date,status=body.enrolment_status,admission_category=body.admission_category,seat_category=body.seat_category,admission_reference=body.admission_reference,change_reason=body.change_reason)
    db.add(e); db.flush()
    db.add(RecordChange(enrolment_id=e.id,record_version=1,change_type="created",before_state={},after_state={"status":e.status,"seat_category":e.seat_category,"cohort":e.cohort},actor_id=user.id,change_reason=body.change_reason))
    ev=emit_event(db,"enrolment.created",e.id,{"institution_id":e.institution_id,"programme_id":e.programme_id,"cohort":e.cohort,"version":1,"source":source})
    audit(db,user,"create_enrolment","enrolment",e.id,{},student_dict(db,e))
    if commit_now:
        db.commit(); process_event(ev.id)
    else:
        db.flush()
    db.refresh(e); return student_dict(db,e)

@app.post("/api/students")
def add_student(body:StudentIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role not in ["Institution Administrator","Data Uploader","AICTE Administrator","AICTE Officer"]: raise HTTPException(403,"Not permitted to add records")
    return create_enrolment(db,body,user)

@app.patch("/api/students/{enrolment_id}")
def update_student(enrolment_id:str,body:StudentPatch,db:Session=Depends(get_db),user:User=Depends(get_current_user),commit_now=True):
    if user.role not in ["Institution Administrator","Data Uploader","AICTE Administrator","AICTE Officer"]: raise HTTPException(403,"Not permitted to edit records")
    e=db.get(Enrolment,enrolment_id)
    if not e: raise HTTPException(404,"Enrolment not found")
    scope_institution(user,e.institution_id); s=db.get(Student,e.student_id)
    before={"name":s.full_name,"identity_status":s.identity_status,"status":e.status,"seat_category":e.seat_category,"programme_id":e.programme_id,"cohort":e.cohort,"version":e.version}
    data=body.model_dump(exclude_unset=True); reason=data.pop("change_reason", "Record corrected")
    if "student_name" in data: s.full_name=data["student_name"]
    if "dob" in data: s.dob=data["dob"]
    if "apaar_id" in data:
        ap=data["apaar_id"].strip() if data["apaar_id"] else None; s.apaar_encrypted=encrypt_value(ap); s.apaar_lookup=apaar_hash(ap) if check_apaar(ap)=="format_valid" else None; s.identity_status=check_apaar(ap)
    for key in ["enrolment_status","admission_category","seat_category","admission_date","cohort"]:
        if key in data: setattr(e, {"enrolment_status":"status"}.get(key,key), data[key])
    old_scope=(e.institution_id,e.programme_id,e.cohort)
    if "programme_id" in data:
        p=db.get(Program,data["programme_id"])
        if not p or p.institution_id!=e.institution_id: raise HTTPException(400,"Programme must belong to the same institution")
        e.programme_id=p.id
    e.version+=1; e.change_reason=reason; e.updated_at=datetime.utcnow(); s.updated_at=datetime.utcnow()
    after={"name":s.full_name,"identity_status":s.identity_status,"status":e.status,"seat_category":e.seat_category,"programme_id":e.programme_id,"cohort":e.cohort,"version":e.version}
    db.add(RecordChange(enrolment_id=e.id,record_version=e.version,change_type="updated",before_state=before,after_state=after,actor_id=user.id,change_reason=reason))
    ev=emit_event(db,"enrolment.updated",e.id,{"old_scope":{"institution_id":old_scope[0],"programme_id":old_scope[1],"cohort":old_scope[2]},"institution_id":e.institution_id,"programme_id":e.programme_id,"cohort":e.cohort,"version":e.version})
    audit(db,user,"update_enrolment","enrolment",e.id,before,after)
    if commit_now:
        db.commit(); process_event(ev.id)
    else:
        db.flush()
    return {**student_dict(db,e),"identity_status":s.identity_status}

@app.get("/api/uploads/template")
def upload_template(user:User=Depends(get_current_user)):
    fields=["institutional_student_id","student_name","apaar_id","dob","institution_code","programme_code","cohort","admission_date","enrolment_status","admission_category","seat_category","admission_reference"]
    buff=io.StringIO(); w=csv.writer(buff); w.writerow(fields); w.writerow(["WIT-NEW-001","Sample Student","202612345678","2006-04-15","WIT001","BTECH-CSE","2026–27","2026-06-01","active","General","regular","WIT-ADM-NEW-001"])
    return StreamingResponse(iter([buff.getvalue()]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=i2i_student_upload_template.csv"})

@app.post("/api/uploads")
async def upload_students(file:UploadFile=File(...),institution_id:str=Form(...),programme_id:str=Form(...),cohort:str=Form(...),db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role not in ["Institution Administrator","Data Uploader","AICTE Administrator","AICTE Officer"]: raise HTTPException(403,"Not permitted to upload")
    scope_institution(user,institution_id); ensure_institution_program(db,user,institution_id,programme_id,cohort)
    filename=file.filename or "upload.csv"; content=await file.read()
    if len(content)>15*1024*1024: raise HTTPException(413,"File exceeds the 15 MB prototype limit")
    if not filename.lower().endswith((".csv",".xlsx",".xls")): raise HTTPException(400,"Only CSV and Excel files are supported")
    fingerprint=hashlib.sha256(content+institution_id.encode()+programme_id.encode()+cohort.encode()).hexdigest()
    existing=db.scalar(select(UploadBatch).where(UploadBatch.fingerprint==fingerprint))
    if existing: return {"batch_id":existing.id,"duplicate_submission":True,"result":existing.result_json,"message":"This exact batch was already processed. Original result returned."}
    try:
        if filename.lower().endswith(".csv"):
            df=pd.read_csv(io.BytesIO(content),dtype=str).fillna("")
        else: df=pd.read_excel(io.BytesIO(content),dtype=str).fillna("")
    except Exception as e: raise HTTPException(400,f"Could not parse file: {str(e)[:160]}")
    required={"institutional_student_id","student_name"}
    if not required.issubset(set(df.columns)): raise HTTPException(400,"Required columns: institutional_student_id and student_name. Download the I2I template.")
    batch=UploadBatch(institution_id=institution_id,programme_id=programme_id,cohort=cohort,filename=filename,fingerprint=fingerprint,total_rows=len(df),created_by=user.id,status="processing")
    db.add(batch); db.flush()
    accepted=[]; rejected=[]; warnings=[]; within_batch={}
    inst=db.get(Institution,institution_id); prog=db.get(Program,programme_id)
    for idx,row in df.iterrows():
        rowno=int(idx)+2; errors=[]; warns=[]
        sid=str(row.get("institutional_student_id","")).strip(); name=str(row.get("student_name","")).strip(); ap=str(row.get("apaar_id","")).strip() or None
        if not sid: errors.append("Institutional student ID is required")
        if not name: errors.append("Student name is required")
        if ap and not re.fullmatch(r"\d{12}",ap): warns.append("APAAR ID is not in the expected 12-digit format")
        if not ap: warns.append("APAAR ID is missing; the provisional record will still be counted")
        ref=str(row.get("admission_reference","")).strip() or None
        if ref and ref in within_batch: warns.append(f"Admission reference repeats row {within_batch[ref]}")
        elif ref: within_batch[ref]=rowno
        def parse_date(v):
            if not str(v).strip(): return None
            try: return pd.to_datetime(str(v),errors="raise").date()
            except: return None
        if str(row.get("dob","")).strip() and parse_date(row.get("dob")) is None: errors.append("Date of birth is invalid")
        if str(row.get("admission_date","")).strip() and parse_date(row.get("admission_date")) is None: errors.append("Admission date is invalid")
        if errors:
            rejected.append({"row":rowno,"institutional_student_id":sid,"errors":errors,"warnings":warns}); continue
        cat=str(row.get("seat_category","regular")).strip().lower() or "regular"
        stat=str(row.get("enrolment_status","active")).strip().lower() or "active"
        if stat not in ["active","enrolled","withdrawn","transferred","completed"]: errors.append("Unsupported enrolment status")
        if errors:
            rejected.append({"row":rowno,"institutional_student_id":sid,"errors":errors,"warnings":warns}); continue
        b=StudentIn(institutional_student_id=sid,student_name=name,apaar_id=ap,dob=parse_date(row.get("dob")),institution_id=institution_id,programme_id=programme_id,cohort=cohort,admission_date=parse_date(row.get("admission_date")),enrolment_status=stat,admission_category=str(row.get("admission_category","General")) or "General",seat_category=cat,admission_reference=ref,change_reason=f"Bulk upload {filename} row {rowno}")
        out=create_enrolment(db,b,user,source="bulk_upload")
        accepted.append({"row":rowno,"enrolment_id":out["enrolment_id"],"institutional_student_id":sid,"student_name":name,"apaar_status":out["apaar_format_status"],"warnings":warns})
        if warns: warnings.append({"row":rowno,"institutional_student_id":sid,"warnings":warns})
    batch.total_rows=len(df); batch.accepted_rows=len(accepted); batch.rejected_rows=len(rejected); batch.warning_rows=len(warnings); batch.status="completed" if not rejected else "completed_with_errors"
    batch.result_json={"accepted":accepted,"rejected":rejected,"warnings":warnings,"total_rows":len(df)}
    audit(db,user,"bulk_upload","upload_batch",batch.id,{}, {"accepted":len(accepted),"rejected":len(rejected),"filename":filename}); db.commit()
    return {"batch_id":batch.id,"filename":filename,"status":batch.status,"total_rows":len(df),"accepted_rows":len(accepted),"rejected_rows":len(rejected),"warning_rows":len(warnings),"accepted":accepted,"rejected":rejected,"warnings":warnings}

@app.get("/api/uploads")
def get_uploads(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,None); xs=db.scalars(select(UploadBatch).where(UploadBatch.institution_id==iid) if iid else select(UploadBatch).order_by(UploadBatch.created_at.desc())).all()
    return [{"id":x.id,"filename":x.filename,"total_rows":x.total_rows,"accepted_rows":x.accepted_rows,"rejected_rows":x.rejected_rows,"warning_rows":x.warning_rows,"status":x.status,"created_at":iso(x.created_at),"result":x.result_json} for x in xs]

@app.get("/api/approvals")
def get_approvals(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,None); xs=db.scalars(select(Approval).where(Approval.institution_id==iid) if iid else select(Approval).order_by(Approval.created_at.desc())).all(); return [approval_dict(x) for x in xs]
@app.post("/api/approvals")
def create_approval(body:ApprovalIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role not in ["AICTE Administrator","AICTE Officer"]: raise HTTPException(403,"Only authorised AICTE roles can configure approval references")
    prog=db.get(Program,body.programme_id)
    if not prog or prog.institution_id!=body.institution_id or prog.cohort!=body.cohort: raise HTTPException(400,"Programme scope does not match approval")
    prior=db.scalar(select(Approval).where(Approval.institution_id==body.institution_id,Approval.programme_id==body.programme_id,Approval.cohort==body.cohort).order_by(Approval.version.desc()))
    if prior: prior.status="Superseded"; version=prior.version+1
    else: version=1
    a=Approval(**body.model_dump(),version=version,created_by=user.id); db.add(a); db.flush(); audit(db,user,"create_approval","approval",a.id,{},approval_dict(a)); db.commit()
    run_reconciliation(db,a.institution_id,a.programme_id,a.cohort); db.commit(); return approval_dict(a)

@app.put("/api/reports/institution")
def upsert_report(body:ReportIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role not in ["Institution Administrator","AICTE Administrator","AICTE Officer"]: raise HTTPException(403,"Not permitted to update institution reports")
    ensure_institution_program(db,user,body.institution_id,body.programme_id,body.cohort)
    r=db.scalar(select(InstitutionReport).where(InstitutionReport.institution_id==body.institution_id,InstitutionReport.programme_id==body.programme_id,InstitutionReport.cohort==body.cohort))
    before={"reported_total":r.reported_total} if r else {}
    if r: r.reported_total=body.reported_total; r.updated_by=user.id; r.updated_at=datetime.utcnow()
    else: r=InstitutionReport(**body.model_dump(),updated_by=user.id); db.add(r)
    db.flush(); audit(db,user,"update_reported_total","institution_report",r.id,before,{"reported_total":r.reported_total}); db.commit(); run_reconciliation(db,body.institution_id,body.programme_id,body.cohort); db.commit(); return {"reported_total":r.reported_total,"status":"saved_and_reconciled"}

@app.get("/api/reconciliation")
def get_reconciliation(institution_id:Optional[str]=None,programme_id:Optional[str]=None,cohort:Optional[str]=None,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,institution_id); stmt=select(ReconciliationRun)
    if iid: stmt=stmt.where(ReconciliationRun.institution_id==iid)
    if programme_id: stmt=stmt.where(ReconciliationRun.programme_id==programme_id)
    if cohort: stmt=stmt.where(ReconciliationRun.cohort==cohort)
    xs=db.scalars(stmt.order_by(ReconciliationRun.created_at.desc()).limit(100)).all()
    result=[]
    for x in xs:
        i=db.get(Institution,x.institution_id); p=db.get(Program,x.programme_id)
        result.append({"id":x.id,"institution":i.name,"institution_id":x.institution_id,"programme":p.name,"programme_id":x.programme_id,"cohort":x.cohort,"student_level_total":x.student_level_total,"active_regular":x.active_regular,"active_additional":x.active_additional,"reported_total":x.reported_total,"regular_intake":x.regular_intake,"additional_capacity":x.additional_capacity,"difference":x.difference,"status":x.status,"created_at":iso(x.created_at)})
    return result
@app.post("/api/reconciliation/run")
def manual_reconcile(institution_id:str,programme_id:str,cohort:str,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    ensure_institution_program(db,user,institution_id,programme_id,cohort); run=run_reconciliation(db,institution_id,programme_id,cohort); audit(db,user,"manual_reconciliation","scope",f"{institution_id}:{programme_id}:{cohort}"); db.commit(); return {"run_id":run.id,"status":run.status,"student_level_total":run.student_level_total,"reported_total":run.reported_total,"difference":run.difference}

@app.get("/api/findings")
def get_findings(status:Optional[str]=None,q:Optional[str]=None,institution_id:Optional[str]=None,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,institution_id); stmt=select(Finding)
    if iid: stmt=stmt.where(Finding.institution_id==iid)
    if status: stmt=stmt.where(Finding.status==status)
    xs=db.scalars(stmt.order_by(Finding.updated_at.desc())).all(); out=[finding_dict(db,f) for f in xs]
    if q: out=[x for x in out if q.lower() in (x["finding_code"]+x["title"]+x["institution"]+x["explanation"]).lower()]
    return out
@app.get("/api/findings/{finding_id}")
def get_finding(finding_id:str,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    f=db.get(Finding,finding_id) or db.scalar(select(Finding).where(Finding.finding_code==finding_id))
    if not f: raise HTTPException(404,"Finding not found")
    scope_institution(user,f.institution_id)
    responses=db.scalars(select(FindingResponse).where(FindingResponse.finding_id==f.id).order_by(FindingResponse.created_at)).all()
    return {**finding_dict(db,f),"responses":[{"response_text":r.response_text,"evidence_name":r.evidence_name,"created_at":iso(r.created_at),"user":db.get(User,r.user_id).full_name} for r in responses]}
@app.post("/api/findings/{finding_id}/responses")
def respond_finding(finding_id:str,body:FindingResponseIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    f=db.get(Finding,finding_id)
    if not f: raise HTTPException(404,"Finding not found")
    scope_institution(user,f.institution_id)
    if user.role not in ["Institution Administrator","Data Uploader","AICTE Administrator","AICTE Officer"]: raise HTTPException(403,"Cannot respond to this finding")
    r=FindingResponse(finding_id=f.id,user_id=user.id,response_text=body.response_text,evidence_name=body.evidence_name); db.add(r); f.status="institution_response_submitted"; f.updated_at=datetime.utcnow(); audit(db,user,"submit_finding_response","finding",f.id,{}, {"response":body.response_text,"evidence":body.evidence_name}); db.commit()
    return {"ok":True,"status":f.status}
@app.post("/api/findings/{finding_id}/decisions")
def decide_finding(finding_id:str,body:DecisionIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role not in ["AICTE Administrator","AICTE Officer"]: raise HTTPException(403,"Only authorised AICTE reviewers can record a decision")
    f=db.get(Finding,finding_id)
    if not f: raise HTTPException(404,"Finding not found")
    before={"status":f.status}; d=body.decision.lower()
    mapping={"resolve":"resolved","dismiss":"dismissed","escalate":"escalated","review":"under_review","request_information":"needs_information"}
    if d not in mapping: raise HTTPException(400,"Decision must be resolve, dismiss, escalate, review or request_information")
    if not body.reason.strip(): raise HTTPException(400,"A reason is required")
    f.status=mapping[d]; f.reviewer_id=user.id; f.resolution_reason=body.reason; f.updated_at=datetime.utcnow(); f.resolved_at=datetime.utcnow() if d in ["resolve","dismiss"] else None
    audit(db,user,"finding_decision","finding",f.id,before,{"status":f.status,"reason":body.reason}); db.commit(); return finding_dict(db,f)

@app.get("/api/audit")
def get_audit(limit:int=100,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    stmt=select(AuditLog).order_by(AuditLog.created_at.desc()).limit(min(max(limit,1),500))
    if user.institution_id and user.role not in ROLE_READ_ALL:
        # Audit scope limited via enrolment and finding ownership; user-specific events are a safe baseline.
        stmt=stmt.where(or_(AuditLog.actor_id==user.id,AuditLog.entity_id.in_([x.id for x in db.scalars(select(Enrolment).where(Enrolment.institution_id==user.institution_id)).all()])))
    xs=db.scalars(stmt).all(); return [{"id":x.id,"actor_id":x.actor_id,"actor_role":x.actor_role,"action":x.action,"entity_type":x.entity_type,"entity_id":x.entity_id,"before":x.before_state,"after":x.after_state,"created_at":iso(x.created_at)} for x in xs]


@app.get("/api/profile")
def profile(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    phone=decrypt_value(user.phone_encrypted)
    return {"user":user_dict(user),"phone_masked":mask_phone(phone) if phone else None,"phone_verified":user.phone_verified,"sms_enabled":user.sms_enabled}

@app.post("/api/findings/{finding_id}/evidence")
async def attach_finding_evidence(finding_id:str,file:UploadFile=File(...),db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    f=db.get(Finding,finding_id)
    if not f: raise HTTPException(404,"Finding not found")
    scope_institution(user,f.institution_id)
    ext=Path(file.filename or "evidence").suffix.lower()
    if ext not in {".pdf",".png",".jpg",".jpeg",".csv",".xlsx"}: raise HTTPException(400,"Unsupported evidence file type")
    data=await file.read()
    if len(data)>10*1024*1024: raise HTTPException(413,"Evidence file exceeds 10 MB")
    evidence_id=str(uuid.uuid4()); target=UPLOAD_DIR/f"evidence-{evidence_id}{ext}"; target.write_bytes(data); os.chmod(target,0o600)
    evidence=list(f.evidence or []); evidence.append({"id":evidence_id,"filename":file.filename,"size":len(data),"uploaded_by":user.id,"uploaded_at":datetime.utcnow().isoformat()}); f.evidence=evidence; f.updated_at=datetime.utcnow()
    audit(db,user,"attach_finding_evidence","finding",f.id,{}, {"evidence_id":evidence_id,"filename":file.filename}); db.commit()
    return {"evidence_id":evidence_id,"filename":file.filename,"size":len(data)}

@app.get("/api/findings/{finding_id}/evidence/{evidence_id}")
def download_finding_evidence(finding_id:str,evidence_id:str,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    f=db.get(Finding,finding_id)
    if not f: raise HTTPException(404,"Finding not found")
    scope_institution(user,f.institution_id)
    item=next((x for x in (f.evidence or []) if x.get("id")==evidence_id),None)
    if not item: raise HTTPException(404,"Evidence not found")
    ext=Path(item.get("filename") or "evidence").suffix.lower()
    target=UPLOAD_DIR/f"evidence-{evidence_id}{ext}"
    if not target.exists(): raise HTTPException(404,"Evidence file is unavailable")
    return FileResponse(target,filename=item.get("filename") or "evidence",media_type="application/octet-stream")

@app.post("/api/verification/requests")
def create_verification(body:VerifyIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role not in ["Authorised Verifier","AICTE Administrator","AICTE Officer","Institution Administrator"]: raise HTTPException(403,"Not authorised to request verification")
    if not body.consent_confirmed or not body.authorisation_reference.strip(): raise HTTPException(400,"Purpose and authorisation must be confirmed")
    e=db.get(Enrolment,body.enrolment_id)
    if not e: raise HTTPException(404,"Enrolment reference not found")
    scope_institution(user,e.institution_id)
    s=db.get(Student,e.student_id); inst=db.get(Institution,e.institution_id); prog=db.get(Program,e.programme_id)
    code="VR-"+secrets.token_hex(4).upper()
    status="active" if e.status.lower() in ["active","enrolled"] else e.status
    payload={"enrolment_status":status,"institution":inst.name,"programme":prog.name,"cohort":e.cohort,"identity_status":s.identity_status,"verified_at":datetime.utcnow().isoformat(),"external_apaar_authentication":"not_performed"}
    v=VerificationRequest(verification_code=code,requester_id=user.id,enrolment_id=e.id,purpose=body.purpose,authorisation_reference=body.authorisation_reference,consent_confirmed=True,result_status="completed",response_payload=payload); db.add(v); db.flush(); audit(db,user,"verification_request","verification",v.id,{},payload); db.commit()
    return {"verification_id":code,"status":"completed","result":payload,"notice":"This is an internal I2I record check, not external APAAR authentication."}

@app.get("/api/reports/{report_type}")
def reports(report_type:str,format:str="csv",db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,None); rows=[]
    if report_type in ["enrolment","reconciliation"]:
        for p in db.scalars(select(Program).where(Program.institution_id==iid) if iid else select(Program)).all():
            run=run_reconciliation(db,p.institution_id,p.id,p.cohort); i=db.get(Institution,p.institution_id)
            rows.append({"institution":i.name,"programme":p.name,"cohort":p.cohort,"student_level_total":run.student_level_total,"active_regular":run.active_regular,"active_additional":run.active_additional,"reported_total":run.reported_total,"regular_intake":run.regular_intake,"difference":run.difference,"status":run.status})
        db.commit()
    elif report_type=="findings":
        stmt=select(Finding).where(Finding.institution_id==iid) if iid else select(Finding)
        for f in db.scalars(stmt).all(): rows.append({"finding_code":f.finding_code,"type":f.finding_type,"title":f.title,"status":f.status,"severity":f.severity,"expected":f.expected_value,"observed":f.observed_value,"created_at":iso(f.created_at)})
    elif report_type=="audit":
        for a in db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(1000)).all(): rows.append({"action":a.action,"role":a.actor_role,"entity_type":a.entity_type,"entity_id":a.entity_id,"created_at":iso(a.created_at)})
    else: raise HTTPException(404,"Unknown report type")
    if format.lower()=="json": return rows
    if not rows: rows=[{"message":"No records in this report scope"}]
    buff=io.StringIO(); writer=csv.DictWriter(buff,fieldnames=list(rows[0].keys())); writer.writeheader(); writer.writerows(rows)
    return StreamingResponse(iter([buff.getvalue()]),media_type="text/csv",headers={"Content-Disposition":f"attachment; filename=i2i_{report_type}_report.csv"})

@app.get("/api/notifications")
def notifications(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    xs=db.scalars(select(Notification).where(Notification.user_id==user.id).order_by(Notification.created_at.desc()).limit(100)).all()
    return [{"id":n.id,"event_type":n.event_type,"title":n.title,"body":n.body,"link":n.link,"read":n.read_at is not None,"created_at":iso(n.created_at),"sms_status":n.sms_status} for n in xs]
@app.post("/api/notifications/{notification_id}/read")
def mark_notification(notification_id:str,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    n=db.get(Notification,notification_id)
    if not n or n.user_id!=user.id: raise HTTPException(404,"Notification not found")
    n.read_at=datetime.utcnow(); db.commit(); return {"ok":True}

# Generic SMS adapter: live delivery requires a configured endpoint and credentials.
def send_sms_gateway(phone:str,message:str)->tuple[str,Optional[str],str]:
    mode=os.getenv("SMS_MODE","demo").lower()
    if mode!="live": return "simulated_demo",None,"Demo mode: no real SMS sent"
    url=os.getenv("SMS_GATEWAY_URL",""); key=os.getenv("SMS_API_KEY","")
    if not url or not key: return "failed",None,"Live mode requires SMS_GATEWAY_URL and SMS_API_KEY"
    try:
        resp=httpx.post(url,json={"to":phone,"message":message,"sender_id":os.getenv("SMS_SENDER_ID",""),"template_id":os.getenv("SMS_TEMPLATE_ID","")},headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"},timeout=15)
        resp.raise_for_status(); data=resp.json() if "application/json" in resp.headers.get("content-type","") else {}
        return "sent_to_provider",str(data.get("message_id") or data.get("request_id") or "") or None,"Provider accepted request; delivery confirmation may arrive separately"
    except Exception as e: return "failed",None,str(e)[:300]

def mask_phone(phone): return ("*"*(max(0,len(phone)-4)))+phone[-4:]
@app.post("/api/profile/mobile")
def save_mobile(body:PhoneIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    phone=re.sub(r"[\s()-]","",body.phone)
    if not re.fullmatch(r"\+?[1-9]\d{7,14}",phone): raise HTTPException(400,"Enter a valid international mobile number, e.g. +91XXXXXXXXXX")
    user.phone_encrypted=encrypt_value(phone); user.phone_verified=False; db.commit()
    return {"phone_masked":mask_phone(phone),"verified":False}
@app.post("/api/profile/mobile/send-otp")
def send_otp(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    phone=decrypt_value(user.phone_encrypted)
    if not phone: raise HTTPException(400,"Save a mobile number first")
    recent=db.scalar(select(func.count(OtpChallenge.id)).where(OtpChallenge.user_id==user.id,OtpChallenge.created_at>datetime.utcnow()-timedelta(minutes=10))) or 0
    if recent>=5: raise HTTPException(429,"OTP limit reached. Try again later.")
    otp=f"{secrets.randbelow(1000000):06d}"; challenge=OtpChallenge(user_id=user.id,otp_hash=hashlib.sha256((otp+SECRET_KEY).encode()).hexdigest(),expires_at=datetime.utcnow()+timedelta(minutes=5)); db.add(challenge)
    status,ref,detail=send_sms_gateway(phone,f"Your I2I mobile verification code is {otp}. It expires in 5 minutes.")
    db.add(SmsLog(user_id=user.id,phone_masked=mask_phone(phone),message_type="otp",provider_status=status,provider_reference=ref,detail=detail))
    db.commit()
    result={"challenge_id":challenge.id,"status":status,"expires_in_seconds":300}
    if os.getenv("SMS_MODE","demo").lower()!="live": result["demo_otp"]=otp
    if status=="failed": raise HTTPException(502,detail)
    return result
@app.post("/api/profile/mobile/verify-otp")
def verify_otp(body:OtpVerifyIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    c=db.get(OtpChallenge,body.challenge_id)
    if not c or c.user_id!=user.id or c.consumed or c.expires_at<datetime.utcnow() or c.attempts>=5: raise HTTPException(400,"OTP challenge is invalid or expired")
    c.attempts+=1
    expected=hashlib.sha256((body.otp+SECRET_KEY).encode()).hexdigest()
    if not hmac.compare_digest(expected,c.otp_hash): db.commit(); raise HTTPException(400,"Incorrect OTP")
    c.consumed=True; user.phone_verified=True; audit(db,user,"verify_mobile","user",user.id); db.commit(); return {"verified":True,"phone_masked":mask_phone(decrypt_value(user.phone_encrypted))}
@app.put("/api/profile/notifications")
def notification_preferences(enabled:bool,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    user.sms_enabled=enabled; db.commit(); return {"sms_enabled":enabled,"phone_verified":user.phone_verified}

@app.post("/api/sync/push")
def sync_push(operations:list[SyncOpIn],db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    results=[]
    for op in operations:
        iid=scope_institution(user,op.institution_id)
        prior=db.scalar(select(SyncOperation).where(SyncOperation.op_id==op.op_id))
        if prior:
            results.append({"op_id":op.op_id,"status":prior.status,"result":prior.result,"idempotent_replay":True}); continue
        try:
            if op.op_type=="student.create":
                body=StudentIn(**op.payload)
                if body.institution_id!=iid: raise HTTPException(403,"Operation institution does not match account scope")
                created=create_enrolment(db,body,user,source="offline_sync",commit_now=False)
                result={"enrolment_id":created["enrolment_id"]}; status="synced"; record_id=created["enrolment_id"]
            elif op.op_type=="student.update":
                target=db.get(Enrolment,op.record_id) if op.record_id else None
                if not target: raise HTTPException(404,"Record not found")
                if op.base_server_version is not None and target.version!=op.base_server_version:
                    result={"server_version":target.version,"local_base_version":op.base_server_version,"server_record":student_dict(db,target)}; status="conflict"; record_id=target.id
                else:
                    updated=update_student(target.id,StudentPatch(**op.payload),db,user,commit_now=False)
                    result={"enrolment_id":target.id,"updated":updated}; status="synced"; record_id=target.id
            else:
                result={"error":"Unsupported operation type"}; status="failed"; record_id=op.record_id
            rec=SyncOperation(op_id=op.op_id,institution_id=iid,op_type=op.op_type,payload=op.payload,record_id=record_id,base_server_version=op.base_server_version,local_version=op.local_version,status=status,result=result,synced_at=datetime.utcnow() if status=="synced" else None)
            db.add(rec); db.commit()
            if status=="synced": process_pending_events()
            results.append({"op_id":op.op_id,"status":status,"result":result,"idempotent_replay":False})
        except HTTPException:
            db.rollback(); raise
        except Exception as ex:
            db.rollback(); results.append({"op_id":op.op_id,"status":"failed","result":{"error":str(ex)[:240]},"idempotent_replay":False})
    return {"results":results}
@app.get("/api/sync/status")
def sync_status(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    iid=scope_institution(user,None); stmt=select(SyncOperation).where(SyncOperation.institution_id==iid) if iid else select(SyncOperation)
    xs=db.scalars(stmt.order_by(SyncOperation.created_at.desc()).limit(100)).all()
    return {"counts":{k:sum(1 for x in xs if x.status==k) for k in ["pending","synced","conflict","failed"]},"operations":[{"op_id":x.op_id,"op_type":x.op_type,"record_id":x.record_id,"status":x.status,"result":x.result,"retry_count":x.retry_count,"created_at":iso(x.created_at),"synced_at":iso(x.synced_at)} for x in xs]}

# I2I Bot: deterministic, role-aware assistance grounded in the live workspace.
def assistant_answer(db,user,msg,context):
    q=msg.lower().strip(); iid=scope_institution(user,context.get("institution_id"))
    if "finding" in q or context.get("context_type")=="finding":
        code=context.get("context_id") or next((x for x in re.findall(r"I2I-[A-F0-9]{6}",msg.upper())),None)
        f=db.get(Finding,code) if code else None
        if not f and code: f=db.scalar(select(Finding).where(Finding.finding_code==code))
        if f:
            scope_institution(user,f.institution_id)
            return {"text":f"{f.finding_code}: {f.title}. {f.explanation} Expected: {f.expected_value or 'Not configured'}. Observed: {f.observed_value or 'Not available'}. Next action: {f.required_action}","cards":[{"type":"finding","title":f.title,"status":f.status,"finding_code":f.finding_code,"link":f"/findings/{f.id}"}],"actions":[{"label":"Open finding","page":"findings","id":f.id}]}
        return {"text":"I could not identify that finding in the records you can access. Open a finding and choose 'Explain this finding' to provide its context.","cards":[],"actions":[]}
    if "apa ar" in q or "apaar" in q:
        match=re.search(r"\b\d{12}\b",msg)
        if match:
            ap=match.group(0); h=apaar_hash(ap); matches=db.scalars(select(Student).where(Student.apaar_lookup==h)).all()
            return {"text":f"The supplied value has the expected 12-digit format. I2I found {len(matches)} matching identity record(s) in the accessible workspace. This is a local format and record-match check only; it does not authenticate the identity with APAAR/ABC.","cards":[{"type":"identity_check","format_status":"valid_format","matching_records":len(matches),"external_verification":"not_performed"}],"actions":[]}
        return {"text":"APAAR is stored as a protected identity reference. I2I checks whether the value is present and matches the expected 12-digit format, and can detect repeated references in accessible records. A format check does not prove official authenticity. What would you like to do: check a format, review a missing ID, or open duplicate candidates?","cards":[],"actions":[{"label":"Open students","page":"students"}]}
    if any(w in q for w in ["compare","intake","enrolment","enrollment","reported total","count"]):
        stmt=select(Program).where(Program.institution_id==iid) if iid else select(Program)
        progs=db.scalars(stmt).all(); cards=[]
        for p in progs:
            run=run_reconciliation(db,p.institution_id,p.id,p.cohort)
            inst=db.get(Institution,p.institution_id)
            cards.append({"type":"reconciliation","institution":inst.name,"programme":p.name,"cohort":p.cohort,"student_count":run.student_level_total,"reported_total":run.reported_total,"regular_intake":run.regular_intake,"difference":run.difference,"status":run.status})
        db.commit()
        return {"text":"Here is the latest scoped comparison available to your account. Counts include active enrolment records in each institution/programme/cohort scope; missing APAAR does not remove an admission from the count.","cards":cards,"actions":[{"label":"Open reconciliation","page":"reconcile"}]}
    if "upload" in q or "csv" in q or "excel" in q:
        return {"text":"For a student upload: choose your institution, programme and admission cohort; download the I2I CSV template; map the institutional student ID, student name and APAAR ID columns; preview row-level errors; then confirm import. Missing APAAR is a warning, not an automatic rejection. Accepted records are saved and trigger scoped reconciliation.","cards":[],"actions":[{"label":"Go to bulk upload","page":"upload"}]}
    if "sync" in q or "offline" in q:
        stmt=select(SyncOperation).where(SyncOperation.institution_id==iid) if iid else select(SyncOperation)
        xs=db.scalars(stmt).all(); counts={k:sum(1 for x in xs if x.status==k) for k in ["pending","synced","conflict","failed"]}
        return {"text":f"Your accessible sync queue has {counts['pending']} pending, {counts['synced']} synced, {counts['conflict']} conflicts and {counts['failed']} failed operations. Offline checks are provisional; accepted changes are checked centrally after sync.","cards":[{"type":"sync_summary",**counts}],"actions":[{"label":"Open sync status","page":"sync"}]}
    if "duplicate" in q or "overlap" in q:
        stmt=select(Finding).where(Finding.finding_type.in_(["duplicate_apaar","cross_institution_overlap"]),Finding.status.notin_(["resolved","dismissed"]))
        if iid: stmt=stmt.where(Finding.institution_id==iid)
        fs=db.scalars(stmt.order_by(Finding.created_at.desc()).limit(10)).all()
        return {"text":f"I found {len(fs)} open duplicate or overlap review finding(s) in the accessible scope. A repeated identifier is a review signal, not proof of fraud. Compare admission dates, transfer and withdrawal history before deciding.","cards":[{"type":"finding","title":f.title,"status":f.status,"finding_code":f.finding_code,"link":f"/findings/{f.id}"} for f in fs],"actions":[{"label":"Review findings","page":"findings"}]}
    if "help" in q or "what can" in q or not q:
        return {"text":"I can help with student uploads, APAAR format checks, enrolment and intake comparisons, finding explanations, duplicate review and offline synchronisation. You can also attach a CSV or a finding to give me more context. I only use records your account is permitted to access.","cards":[],"actions":[{"label":"Upload records","page":"upload"},{"label":"Review findings","page":"findings"},{"label":"Compare intake","page":"reconcile"}]}
    return {"text":"I can help with I2I records and workflows. Try asking me to explain a finding, compare enrolment with intake, check an APAAR format, analyse an upload or review offline sync. For a specific answer, attach a record or select the current finding as context.","cards":[],"actions":[]}

@app.post("/api/assistant/chat")
def assistant_chat(body:AssistantIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    conversation=body.conversation_id or str(uuid.uuid4()); context=body.model_dump(exclude={"message","conversation_id"})
    if body.attachment_id:
        meta_path=UPLOAD_DIR/f"assistant-{body.attachment_id}.json"
        if not meta_path.exists(): raise HTTPException(404,"Assistant attachment not found")
        meta=json.loads(meta_path.read_text())
        if meta.get("owner_id")!=user.id: raise HTTPException(403,"Attachment access denied")
        context["attachment_summary"]=meta.get("summary",{})
    result=assistant_answer(db,user,body.message,context)
    attach_summary=context.get("attachment_summary")
    if attach_summary:
        preview=attach_summary.get("preview") or []
        cols=list(preview[0].keys()) if preview else []
        result["text"] += f"\n\nAttached file: {attach_summary.get('filename')} ({attach_summary.get('size')} bytes). Detected columns: {', '.join(cols) if cols else 'No tabular preview available'}. The attachment is private to your account."
        if preview: result["cards"].append({"type":"attachment_preview","filename":attach_summary.get("filename"),"preview_rows":len(preview),"columns":cols})
    db.add(AssistantMessage(user_id=user.id,conversation_id=conversation,role="user",content=body.message,context=context)); db.add(AssistantMessage(user_id=user.id,conversation_id=conversation,role="assistant",content=result["text"],context={"cards":result["cards"],"actions":result["actions"]})); db.commit()
    return {"conversation_id":conversation,**result}
@app.get("/api/assistant/history/{conversation_id}")
def assistant_history(conversation_id:str,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    xs=db.scalars(select(AssistantMessage).where(AssistantMessage.user_id==user.id,AssistantMessage.conversation_id==conversation_id).order_by(AssistantMessage.created_at)).all()
    return [{"role":x.role,"content":x.content,"context":x.context,"created_at":iso(x.created_at)} for x in xs]

@app.post("/api/assistant/attachments")
async def assistant_attachment(file:UploadFile=File(...),db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    name=file.filename or "attachment"; ext=Path(name).suffix.lower(); allowed={".csv",".xlsx",".xls",".pdf"}
    if ext not in allowed: raise HTTPException(400,"Attach CSV, Excel or PDF files only")
    data=await file.read()
    if len(data)>10*1024*1024: raise HTTPException(413,"Attachment exceeds 10 MB")
    aid=str(uuid.uuid4()); target=UPLOAD_DIR/f"assistant-{aid}{ext}"; target.write_bytes(data); os.chmod(target,0o600)
    # Content summary only; attachment is private and tied to owner in a small sidecar record.
    summary={"filename":name,"size":len(data),"type":ext}
    try:
        if ext==".csv": summary["preview"]=pd.read_csv(io.BytesIO(data),nrows=8).fillna("").to_dict(orient="records")
        elif ext in [".xlsx",".xls"]: summary["preview"]=pd.read_excel(io.BytesIO(data),nrows=8).fillna("").to_dict(orient="records")
        else:
            from pypdf import PdfReader
            reader=PdfReader(io.BytesIO(data)); summary["text_preview"]=" ".join((p.extract_text() or "") for p in reader.pages[:3])[:2500]
    except Exception as e: summary["parse_warning"]=str(e)[:180]
    (UPLOAD_DIR/f"assistant-{aid}.json").write_text(json.dumps({"owner_id":user.id,"summary":summary}));
    return {"attachment_id":aid,**summary}

@app.get("/api/users")
def list_users(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role not in ["AICTE Administrator","Auditor"]: raise HTTPException(403,"Not authorised")
    return [{"id":u.id,"username":u.username,"full_name":u.full_name,"email":u.email,"role":u.role,"institution_id":u.institution_id,"phone_verified":u.phone_verified,"active":u.is_active} for u in db.scalars(select(User)).all()]

@app.post("/api/users")
def create_user(body:UserCreateIn,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    if user.role!="AICTE Administrator": raise HTTPException(403,"Only AICTE administrators can create users")
    allowed={"AICTE Administrator","AICTE Officer","Institution Administrator","Data Uploader","Auditor","Authorised Verifier"}
    if body.role not in allowed: raise HTTPException(400,"Unsupported role")
    if db.scalar(select(User).where(or_(User.username==body.username,User.email==body.email))): raise HTTPException(409,"Username or email already exists")
    if body.role in ["Institution Administrator","Data Uploader","Authorised Verifier"] and not body.institution_id: raise HTTPException(400,"This role requires an institution assignment")
    if body.institution_id and not db.get(Institution,body.institution_id): raise HTTPException(404,"Institution not found")
    x=User(username=body.username.strip(),full_name=body.full_name.strip(),email=body.email.strip().lower(),password_hash=ph.hash(body.temporary_password),role=body.role,institution_id=body.institution_id)
    db.add(x); db.flush(); audit(db,user,"create_user","user",x.id,{},user_dict(x)); db.commit(); return user_dict(x)

# Minimal periodic outbox polling for reliable retry in single-process demo deployments.
def worker_loop():
    while True:
        try: process_pending_events()
        except Exception: pass
        time.sleep(2)
threading.Thread(target=worker_loop,daemon=True,name="i2i-outbox-worker").start()


# Serve the standalone application UI and its static assets from the backend origin.
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
@app.get("/", include_in_schema=False)
def home():
    return FileResponse(BASE / "static" / "index.html")
