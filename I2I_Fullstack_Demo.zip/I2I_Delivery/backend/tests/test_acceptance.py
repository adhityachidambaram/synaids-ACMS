import io
from fastapi.testclient import TestClient
import app


def test_end_to_end_acceptance():
    with TestClient(app.app) as client:
        assert client.get('/').status_code == 200
        assert client.get('/static/app.js').status_code == 200
        login = client.post('/api/auth/login', json={'username':'aicte.officer','password':'I2I-Demo-2026!'})
        assert login.status_code == 200
        headers = {'Authorization': 'Bearer ' + login.json()['access_token']}
        bootstrap = client.get('/api/bootstrap', headers=headers).json()
        inst = next(x for x in bootstrap['institutions'] if x['code']=='WIT001')
        prog = next(x for x in bootstrap['programmes'] if x['code']=='BTECH-CSE')

        # 120 -> 121: two separate findings.
        student = {'institutional_student_id':'WIT-TEST-121','student_name':'Synthetic Test Student','apaar_id':'299900001211',
                   'institution_id':inst['id'],'programme_id':prog['id'],'cohort':'2026–27','enrolment_status':'active',
                   'seat_category':'regular','admission_category':'General','change_reason':'Acceptance test'}
        created = client.post('/api/students', headers=headers, json=student)
        assert created.status_code == 200, created.text
        findings = client.get('/api/findings', headers=headers).json()
        scope = [f for f in findings if f['programme_id']==prog['id'] and f['cohort']=='2026–27']
        assert any(f['finding_type']=='intake_capacity' and f['status']=='open' for f in scope)
        assert any(f['finding_type']=='reported_total_mismatch' and f['status']=='open' for f in scope)

        # Correct allocation and declared total, then recalculate.
        patch = client.patch('/api/students/'+created.json()['enrolment_id'], headers=headers,
                             json={'seat_category':'supernumerary','change_reason':'Applicable demo allocation evidence reviewed'})
        assert patch.status_code == 200, patch.text
        report = client.put('/api/reports/institution', headers=headers,
                            json={'institution_id':inst['id'],'programme_id':prog['id'],'cohort':'2026–27','reported_total':121})
        assert report.status_code == 200, report.text
        manual = client.post('/api/reconciliation/run', headers=headers,
                             params={'institution_id':inst['id'],'programme_id':prog['id'],'cohort':'2026–27'})
        assert manual.status_code == 200, manual.text
        assert manual.json()['student_level_total'] == 121
        assert manual.json()['reported_total'] == 121
        assert manual.json()['status'] in ['consistent','needs_review']

        # Real CSV upload, including one missing APAAR (accepted but warned).
        civil = next(x for x in bootstrap['programmes'] if x['code']=='BTECH-CIVIL')
        csv_data = ('institutional_student_id,student_name,apaar_id,cohort,admission_date,enrolment_status,seat_category\n'
                    'WIT-UP-001,Upload Test,299900001301,2026–27,2026-06-01,active,regular\n'
                    'WIT-UP-002,Pending Identity,,2026–27,2026-06-01,active,regular\n')
        up = client.post('/api/uploads', headers=headers,
            data={'institution_id':inst['id'],'programme_id':civil['id'],'cohort':'2026–27'},
            files={'file':('acceptance.csv',csv_data,'text/csv')})
        assert up.status_code == 200, up.text
        assert up.json()['accepted_rows'] == 2
        assert up.json()['warning_rows'] >= 1

        # Verification is explicitly internal I2I verification, not APAAR authentication.
        verifier = client.post('/api/verification/requests', headers=headers, json={
            'enrolment_id':created.json()['enrolment_id'],'purpose':'Acceptance test',
            'authorisation_reference':'DEMO-CONSENT-001','consent_confirmed':True})
        assert verifier.status_code == 200, verifier.text
        assert 'not external APAAR authentication' in verifier.json()['notice']

        # Evidence files are stored privately and can be downloaded only through an authorised route.
        all_findings=client.get('/api/findings',headers=headers).json()
        candidate=next((f for f in all_findings if f['institution_id']==inst['id']),None)
        if candidate:
            evidence=client.post(f"/api/findings/{candidate['id']}/evidence",headers=headers,files={'file':('support.csv',b'proof,value\nexample,1\n','text/csv')})
            assert evidence.status_code==200, evidence.text
            download=client.get(f"/api/findings/{candidate['id']}/evidence/{evidence.json()['evidence_id']}",headers=headers)
            assert download.status_code==200 and b'proof,value' in download.content

        # Reports, I2I Bot and SMS demo OTP.
        assert client.get('/api/reports/reconciliation', headers=headers).status_code == 200
        bot = client.post('/api/assistant/chat', headers=headers, json={'message':'Compare enrolment and intake'})
        assert bot.status_code == 200 and bot.json()['text']
        attachment=client.post('/api/assistant/attachments',headers=headers,files={'file':('context.csv',b'col1,col2\na,b\n','text/csv')})
        assert attachment.status_code==200 and attachment.json()['attachment_id']
        phone = client.post('/api/profile/mobile', headers=headers, json={'phone':'+919876543210'})
        assert phone.status_code == 200
        otp = client.post('/api/profile/mobile/send-otp', headers=headers)
        assert otp.status_code == 200 and otp.json().get('demo_otp')
        verified = client.post('/api/profile/mobile/verify-otp', headers=headers,
                               json={'challenge_id':otp.json()['challenge_id'],'otp':otp.json()['demo_otp']})
        assert verified.status_code == 200

        # Offline create sync is idempotent on replay.
        op = {'op_id':'acceptance-sync-op-001','institution_id':inst['id'],'op_type':'student.create',
              'payload':{'institutional_student_id':'WIT-OFF-001','student_name':'Offline Demo Student','apaar_id':'299900001401',
                         'institution_id':inst['id'],'programme_id':prog['id'],'cohort':'2026–27','enrolment_status':'active',
                         'seat_category':'regular','admission_category':'General'},'local_version':1}
        first = client.post('/api/sync/push', headers=headers, json=[op])
        assert first.status_code == 200 and first.json()['results'][0]['status']=='synced', first.text
        second = client.post('/api/sync/push', headers=headers, json=[op])
        assert second.status_code == 200 and second.json()['results'][0]['idempotent_replay'] is True

        # AICTE administration: institution/programme onboarding and user creation.
        admin_login=client.post('/api/auth/login',json={'username':'aicte.admin','password':'I2I-Demo-2026!'}).json()
        ah={'Authorization':'Bearer '+admin_login['access_token']}
        new_inst=client.post('/api/institutions',headers=ah,json={'code':'TEST900','name':'Test Onboarding Institute','state':'Tamil Nadu','district':'Chennai','institution_type':'Engineering'})
        assert new_inst.status_code==200, new_inst.text
        new_prog=client.post('/api/programmes',headers=ah,json={'code':'TEST900-CSE','institution_id':new_inst.json()['id'],'name':'B.Tech Test Programme','level':'Undergraduate','cohort':'2026–27'})
        assert new_prog.status_code==200, new_prog.text
        new_user=client.post('/api/users',headers=ah,json={'username':'test.upload','full_name':'Test Uploader','email':'test.upload@example.test','role':'Data Uploader','institution_id':new_inst.json()['id'],'temporary_password':'Temporary-I2I-2026!'})
        assert new_user.status_code==200, new_user.text

        # Institution isolation.
        inst_login=client.post('/api/auth/login',json={'username':'wit.admin','password':'I2I-Demo-2026!'}).json()
        ih={'Authorization':'Bearer '+inst_login['access_token']}
        assert client.get('/api/institutions',headers=ih).json() and len(client.get('/api/institutions',headers=ih).json())==1
        assert client.get('/api/users',headers=ih).status_code==403
