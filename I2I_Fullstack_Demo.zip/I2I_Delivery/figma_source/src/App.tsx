import { useMemo, useState } from 'react'

type Page =
  | 'dashboard'
  | 'students'
  | 'upload'
  | 'reconcile'
  | 'findings'
  | 'approvals'
  | 'sync'
  | 'verification'
  | 'reports'
type Role = 'AICTE Officer' | 'Institution Administrator' | 'Data Uploader' | 'Auditor' | 'Authorised Verifier'

const icons: Record<string, string> = {
  grid: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',
  users: 'M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM22 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75',
  upload: 'M12 16V4M7 9l5-5 5 5M4 20h16',
  reconcile: 'M4 7h13M14 4l3 3-3 3M20 17H7M10 14l-3 3 3 3',
  flag: 'M5 21V4m0 0h12l-2 4 2 4H5',
  file: 'M6 2h9l4 4v16H6zM14 2v5h5M9 13h6M9 17h6',
  sync: 'M20 11a8 8 0 00-14.93-3M4 4v4h4M4 13a8 8 0 0014.93 3M20 20v-4h-4',
  check: 'M20 6L9 17l-5-5',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  bell: 'M18 8A6 6 0 006 8c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4',
  search: 'M21 21l-4.35-4.35M19 11a8 8 0 11-16 0 8 8 0 0116 0z',
  arrow: 'M5 12h14M13 6l6 6-6 6',
  close: 'M6 6l12 12M18 6L6 18',
  menu: 'M4 7h16M4 12h16M4 17h16',
  bot: 'M8 9h8M9 13h.01M15 13h.01M7 18h10a3 3 0 003-3V8a3 3 0 00-3-3H7a3 3 0 00-3 3v7a3 3 0 003 3zM12 5V2',
  logout: 'M10 17l5-5-5-5M15 12H3M14 4h5a2 2 0 012 2v12a2 2 0 01-2 2h-5',
  chevron: 'M9 18l6-6-6-6',
  filter: 'M4 5h16l-6 7v6l-4 2v-8z',
  dots: 'M5 12h.01M12 12h.01M19 12h.01',
}

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={icons[name] || icons.check} />
    </svg>
  )
}

function Logo({ light = false }: { light?: boolean }) {
  return (
    <div className={`logo ${light ? 'logo-light' : ''}`}>
      <div className="logo-mark">
        <svg viewBox="0 0 44 44" aria-hidden="true">
          <path className="logo-rail" d="M10 8v28M34 8v28" />
          <path className="logo-link" d="M10 13h8c7 0 9 4 9 9s-2 9-9 9h-8M27 22h7" />
          <circle cx="10" cy="8" r="2.5" />
          <circle cx="34" cy="36" r="2.5" />
        </svg>
      </div>
      <div><strong>I2I</strong><small>Identity · Intake</small></div>
    </div>
  )
}

function Button({ children, variant = 'primary', icon, onClick, type = 'button' }: { children: React.ReactNode; variant?: 'primary' | 'secondary' | 'ghost' | 'dark'; icon?: string; onClick?: () => void; type?: 'button' | 'submit' }) {
  return <button type={type} className={`btn btn-${variant}`} onClick={onClick}>{children}{icon && <Icon name={icon} size={16} />}</button>
}

function Status({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: 'good' | 'warn' | 'bad' | 'neutral' | 'info' }) {
  return <span className={`status status-${tone}`}><i />{children}</span>
}

const metrics = [
  ['Total institutions', '3,842', '+28 this year', 'good'],
  ['Student records', '2.48M', '97.2% validated', 'good'],
  ['Active enrolments', '2.31M', 'AY 2024–25', 'info'],
  ['Pending APAAR status', '68,402', '2.8% of records', 'warn'],
  ['Open findings', '12,640', '1,204 high priority', 'bad'],
  ['Potential duplicates', '4,821', '↓ 8.4% this month', 'good'],
] as const

const students = [
  { id: 'I2I-2401856', name: 'Aarav Mehta', inst: 'Western Institute of Technology', programme: 'B.Tech · CSE', apaar: 'Linked', category: 'General', status: 'Validated' },
  { id: 'I2I-2401857', name: 'Diya Nair', inst: 'Western Institute of Technology', programme: 'B.Tech · CSE', apaar: 'Pending', category: 'OBC-NCL', status: 'Review' },
  { id: 'I2I-2401858', name: 'Kabir Sharma', inst: 'National College of Engineering', programme: 'B.Tech · Civil', apaar: 'Linked', category: 'General', status: 'Validated' },
  { id: 'I2I-2401859', name: 'Meera Iyer', inst: 'Eastern School of Technology', programme: 'MBA', apaar: 'Not provided', category: 'SC', status: 'Action needed' },
  { id: 'I2I-2401860', name: 'Rohan Das', inst: 'Central Institute of Design', programme: 'B.Des · Product', apaar: 'Linked', category: 'General', status: 'Validated' },
] 

const findings = [
  { id: 'F-10882', title: 'Enrolment exceeds approved intake', place: 'Western Institute · B.Tech CSE', value: '+12 seats', level: 'High', age: '2h ago' },
  { id: 'F-10879', title: 'Potential duplicate identity', place: 'Eastern School · MBA', value: '2 records', level: 'High', age: '5h ago' },
  { id: 'F-10871', title: 'Reported total does not reconcile', place: 'Central Institute · B.Des', value: '−4 records', level: 'Medium', age: 'Yesterday' },
]

function Landing({ onLogin }: { onLogin: () => void }) {
  return (
    <main className="landing">
      <nav className="public-nav">
        <Logo />
        <div className="nav-links"><a href="#problem">Why I2I</a><a href="#workflow">How it works</a><a href="#privacy">Trust & privacy</a></div>
        <Button variant="secondary" onClick={onLogin}>Authorised login <Icon name="arrow" size={15} /></Button>
      </nav>

      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span />Identity-to-Intake Reconciliation</div>
          <h1>Every student.<br />Every seat. <em>Reconciled.</em></h1>
          <p>I2I brings student identity, institutional enrolment and approved intake into one accountable view — so every discrepancy has context, evidence and a clear path to resolution.</p>
          <div className="hero-actions">
            <Button onClick={() => document.querySelector('#problem')?.scrollIntoView({ behavior: 'smooth' })} icon="arrow">Explore I2I</Button>
            <Button variant="ghost" onClick={onLogin}>Login to workspace</Button>
          </div>
          <div className="hero-note"><Icon name="check" size={15} /> Purpose-built for AICTE-approved institutions</div>
        </div>
        <div className="identity-map">
          <div className="map-heading"><span>One record, three sources</span><Status tone="good">Trace complete</Status></div>
          <div className="map-watermark">I2I</div>
          <div className="map-input map-identity">
            <div><small>IDENTITY</small><strong>Aarav Mehta</strong><span>APAAR-linked status supplied</span></div>
            <b>98<sup>%</sup></b>
            <i><span /></i>
          </div>
          <div className="map-input map-enrolment">
            <div><small>INSTITUTION RECORD</small><strong>B.Tech · CSE</strong><span>Active student enrolment</span></div>
            <b>126</b>
            <i><span /></i>
          </div>
          <div className="map-input map-intake">
            <div><small>APPROVAL CONTEXT</small><strong>AY 2024–25</strong><span>Applicable approved intake</span></div>
            <b>120</b>
            <i><span /></i>
          </div>
          <div className="map-spine">
            <span className="spine-top">MATCH</span>
            <i /><i /><i />
            <b>COMPARE</b>
          </div>
          <div className="map-outcome">
            <div className="outcome-number"><small>DIFFERENCE</small><strong>+06</strong></div>
            <div><span>EXPLAINABLE RESULT</span><h3>Review six additional seats.</h3><p>Add valid permission evidence or correct the affected student records.</p></div>
            <button onClick={onLogin}>Open finding <Icon name="arrow" size={14} /></button>
          </div>
        </div>
      </section>

      <section className="trust-strip"><span>One accountable record</span><b>Identity</b><i>×</i><b>Enrolment</b><i>×</i><b>Approved intake</b><span>Explainable by design</span></section>

      <section id="problem" className="problem-section">
        <div className="section-label">The gap I2I closes</div>
        <div className="problem-heading"><h2>Totals can agree<br />while records don’t.</h2><p>Disconnected datasets make it difficult to know which student created a difference, what changed, and what must be corrected. I2I turns aggregate mismatches into traceable, student-level action.</p></div>
        <div className="problem-grid">
          <div className="problem-stat"><span>01</span><h3>Fragmented identity</h3><p>Student details vary across uploaded records, institutional systems and identity references.</p></div>
          <div className="problem-stat"><span>02</span><h3>Unexplained totals</h3><p>Reported enrolment and student-level records can diverge without revealing the underlying rows.</p></div>
          <div className="problem-stat accent"><span>03</span><h3>Approval context</h3><p>Intake limits depend on programme, year and applicable permissions — not a single static number.</p></div>
        </div>
      </section>

      <section id="workflow" className="workflow-section">
        <div className="workflow-copy"><div className="section-label light">A continuous control loop</div><h2>From uploaded row<br />to resolved finding.</h2><p>Every update reruns only the checks it affects, preserving an audit-ready chain from source to decision.</p></div>
        <div className="workflow-list">
          {[
            ['01', 'Ingest', 'Map CSV or Excel columns with a guided validation preview.'],
            ['02', 'Validate', 'Check required values, formats, identity signals and duplicates.'],
            ['03', 'Reconcile', 'Compare student records, reported totals and applicable intake.'],
            ['04', 'Resolve', 'Respond with evidence, decide, correct and rerun affected checks.'],
          ].map((x, i) => <div className="workflow-row" key={x[0]}><span>{x[0]}</span><div><h3>{x[1]}</h3><p>{x[2]}</p></div><i className={i === 3 ? 'done' : ''} /></div>)}
        </div>
      </section>

      <section className="feature-section">
        <div className="section-label">Built for accountable operations</div>
        <div className="feature-grid">
          <article className="feature-large"><div><span className="feature-kicker">CHANGE-AWARE RECONCILIATION</span><h2>Change one record.<br />See every effect.</h2><p>I2I traces an edit through student counts, programme totals and findings — then explains which checks changed and why.</p></div><div className="change-log"><span>Student status</span><del>Active</del><b>Withdrawn</b><i>Re-runs 3 checks</i></div></article>
          <article><Icon name="users" /><h3>Student record view</h3><p>Identity status, enrolment history, seat category and a complete change trail.</p></article>
          <article><Icon name="flag" /><h3>Evidence-led findings</h3><p>Responses, supporting records, reviewer decisions and resolution history together.</p></article>
          <article><Icon name="sync" /><h3>Resilient offline sync</h3><p>Continue collection locally with visible upload queues and conflict handling.</p></article>
          <article><Icon name="check" /><h3>Authorised verification</h3><p>Purpose-bound requests and clear results without exposing unnecessary data.</p></article>
        </div>
      </section>

      <section id="privacy" className="privacy-section">
        <div><div className="section-label">Trust, privacy & references</div><h2>Designed to verify.<br />Not to overexpose.</h2></div>
        <div className="privacy-copy"><p>Role-based access, minimised identity display, purpose-bound verification and immutable activity history help institutions work responsibly with student records.</p><ul><li>APAAR-linked status is represented only when supplied in demonstration data; this prototype does not claim live APAAR verification.</li><li>Approval context is always tied to institution, programme and academic year.</li><li>Official references and supporting documents remain attached to each review.</li></ul><a href="https://www.aicte-india.org/" target="_blank" rel="noreferrer">Visit the official AICTE website <Icon name="arrow" size={15} /></a></div>
      </section>

      <footer><Logo light /><p>A clearer line from identity to intake.</p><span>Demonstration platform · Fictional data</span></footer>
    </main>
  )
}

function Login({ onSubmit, onBack }: { onSubmit: (r: Role) => void; onBack: () => void }) {
  const [role, setRole] = useState<Role>('AICTE Officer')
  return (
    <main className="login-page">
      <div className="login-brand">
        <button className="back-link" onClick={onBack}><Icon name="arrow" size={16} /> Back to I2I</button>
        <Logo light />
        <div className="login-message"><div className="eyebrow light"><span />Authorised workspace</div><h1>One view of every record that matters.</h1><p>Secure access for institutional reporting, verification and reconciliation workflows.</p></div>
        <div className="login-steps"><span className="active">Identity</span><i /><span>Records</span><i /><span>Intake</span></div>
      </div>
      <div className="login-form-wrap">
        <form className="login-form" onSubmit={(e) => { e.preventDefault(); onSubmit(role) }}>
          <div><span className="form-step">SECURE SIGN IN</span><h2>Welcome back</h2><p>Choose your authorised role to continue.</p></div>
          <label>Access role<select value={role} onChange={(e) => setRole(e.target.value as Role)}>{['AICTE Officer','Institution Administrator','Data Uploader','Auditor','Authorised Verifier'].map(r => <option key={r}>{r}</option>)}</select></label>
          <label>Official email or user ID<input defaultValue={role === 'AICTE Officer' ? 'officer.demo@aicte.gov.in' : 'admin.demo@wit.edu'} /></label>
          <label>Password<div className="password"><input type="password" defaultValue="demopassword" /><button type="button">Show</button></div></label>
          <div className="form-options"><label><input type="checkbox" defaultChecked /> Remember this device</label><button type="button">Forgot password?</button></div>
          <Button type="submit" icon="arrow">Continue securely</Button>
          <p className="login-disclaimer"><Icon name="check" size={14} /> Demonstration access using fictional data</p>
        </form>
      </div>
    </main>
  )
}

const navItems: { page: Page; icon: string; label: string }[] = [
  { page: 'dashboard', icon: 'grid', label: 'Overview' },
  { page: 'students', icon: 'users', label: 'Students' },
  { page: 'upload', icon: 'upload', label: 'Bulk upload' },
  { page: 'reconcile', icon: 'reconcile', label: 'Reconciliation' },
  { page: 'findings', icon: 'flag', label: 'Findings & review' },
  { page: 'approvals', icon: 'file', label: 'Approvals' },
  { page: 'sync', icon: 'sync', label: 'Offline sync' },
  { page: 'verification', icon: 'check', label: 'Verification' },
  { page: 'reports', icon: 'chart', label: 'Reports' },
]

function Sidebar({ page, setPage, role, onLogout, open, onClose }: { page: Page; setPage: (p: Page) => void; role: Role; onLogout: () => void; open: boolean; onClose: () => void }) {
  return <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
    <div className="side-head"><Logo light /><button onClick={onClose} className="mobile-close"><Icon name="close" /></button></div>
    <div className="workspace-switch"><span>WORKSPACE</span><button><i>{role === 'AICTE Officer' ? 'AI' : 'WI'}</i><div><strong>{role === 'AICTE Officer' ? 'National oversight' : 'Western Institute'}</strong><small>{role}</small></div><Icon name="chevron" size={14} /></button></div>
    <nav className="side-nav">
      <span>WORK</span>
      {navItems.slice(0, 5).map(n => <button key={n.page} className={page === n.page ? 'active' : ''} onClick={() => { setPage(n.page); onClose() }}><Icon name={n.icon} /><span>{n.label}</span>{n.page === 'findings' && <b>12</b>}</button>)}
      <span>MANAGE</span>
      {navItems.slice(5).map(n => <button key={n.page} className={page === n.page ? 'active' : ''} onClick={() => { setPage(n.page); onClose() }}><Icon name={n.icon} /><span>{n.label}</span></button>)}
    </nav>
    <div className="side-footer"><button onClick={onLogout}><Icon name="logout" /><span>Sign out</span></button><div className="user-chip"><i>AM</i><div><strong>Ananya Menon</strong><small>{role}</small></div></div></div>
  </aside>
}

function Topbar({ page, onMenu, onNotify }: { page: Page; onMenu: () => void; onNotify: () => void }) {
  const titles: Record<Page, string> = { dashboard: 'Overview', students: 'Student management', upload: 'Bulk upload', reconcile: 'Reconciliation workspace', findings: 'Findings & review', approvals: 'Approval management', sync: 'Offline synchronisation', verification: 'Enrolment verification', reports: 'Reports & audit' }
  return <header className="topbar"><button className="menu-button" onClick={onMenu}><Icon name="menu" /></button><div><span>AY 2024–25</span><h1>{titles[page]}</h1></div><div className="top-actions"><button className="global-search"><Icon name="search" /><span>Search I2I</span><kbd>⌘ K</kbd></button><button className="notification-button" onClick={onNotify}><Icon name="bell" /><i /></button><Button variant="dark">New action <Icon name="chevron" size={14} /></Button></div></header>
}

function MetricCard({ item }: { item: typeof metrics[number] }) {
  return <div className="metric-card"><span>{item[0]}</span><strong>{item[1]}</strong><small className={`text-${item[3]}`}>{item[2]}</small></div>
}

function Dashboard({ role, setPage }: { role: Role; setPage: (p: Page) => void }) {
  const institution = role !== 'AICTE Officer' && role !== 'Auditor'
  return <>
    <section className="welcome-row"><div><div className="date-line">MONDAY, 17 FEBRUARY</div><h2>{institution ? 'Institution records are 94% reconciled.' : 'Good morning, Ananya.'}</h2><p>{institution ? 'Three actions remain before your AY 2024–25 submission is complete.' : 'Here’s where national enrolment oversight needs attention today.'}</p></div><Button onClick={() => setPage('upload')} icon="upload">{institution ? 'Upload student records' : 'Import records'}</Button></section>
    <section className="metric-grid">
      {(institution ? [
        ['Student records', '3,284', '96.8% validated', 'good'], ['Reported enrolment', '3,210', '6 programmes', 'info'], ['Approved intake', '3,180', 'AY 2024–25', 'neutral'], ['Validation results', '48', 'Rows need attention', 'warn'], ['Correction requests', '7', '2 due this week', 'bad'], ['Sync status', '128', 'Pending upload', 'warn']
      ] as typeof metrics : metrics).map((m) => <MetricCard item={m} key={m[0]} />)}
    </section>
    <section className="dashboard-grid">
      <article className="chart-card">
        <div className="card-heading"><div><span>ENROLMENT MONITORING</span><h3>Reconciliation trend</h3></div><select><option>Last 6 months</option></select></div>
        <div className="chart-legend"><span><i className="purple" />Reconciled</span><span><i className="orange" />Pending review</span></div>
        <div className="line-chart"><div className="axis"><span>100%</span><span>75%</span><span>50%</span><span>25%</span></div><svg viewBox="0 0 620 170" preserveAspectRatio="none"><path className="area" d="M0,145 C90,136 110,100 195,108 S300,65 380,72 S500,40 620,24 L620,170 L0,170Z" /><path className="line" d="M0,145 C90,136 110,100 195,108 S300,65 380,72 S500,40 620,24" /><path className="line second" d="M0,65 C95,72 110,92 195,82 S310,104 380,94 S510,124 620,118" /></svg><div className="months"><span>Sep</span><span>Oct</span><span>Nov</span><span>Dec</span><span>Jan</span><span>Feb</span></div></div>
      </article>
      <article className="priority-card">
        <div className="card-heading"><div><span>PRIORITY QUEUE</span><h3>Needs attention</h3></div><button onClick={() => setPage('findings')}>View all</button></div>
        {findings.map((f, i) => <button className="finding-row" key={f.id} onClick={() => setPage('findings')}><i>{String(i + 1).padStart(2, '0')}</i><div><strong>{f.title}</strong><span>{f.place}</span></div><b>{f.value}</b><Icon name="chevron" size={15} /></button>)}
      </article>
      <article className="institutions-card">
        <div className="card-heading"><div><span>{institution ? 'PROGRAMME STATUS' : 'INSTITUTION-WISE MONITORING'}</span><h3>{institution ? 'Enrolment by programme' : 'Highest review volume'}</h3></div><button>Download</button></div>
        <table><thead><tr><th>{institution ? 'Programme' : 'Institution'}</th><th>Records</th><th>Reconciled</th><th>Findings</th><th>Status</th></tr></thead><tbody>
          {[
            [institution ? 'B.Tech · CSE' : 'Western Institute of Technology', '12,482', '92.4%', '128', 'Review'],
            [institution ? 'B.Tech · Civil' : 'Eastern School of Technology', '9,805', '96.1%', '74', 'On track'],
            [institution ? 'MBA' : 'National College of Engineering', '8,640', '97.8%', '42', 'On track'],
            [institution ? 'B.Des · Product' : 'Central Institute of Design', '5,241', '88.6%', '31', 'Review'],
          ].map(r => <tr key={r[0]}><td><strong>{r[0]}</strong></td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td><td><Status tone={r[4] === 'Review' ? 'warn' : 'good'}>{r[4]}</Status></td></tr>)}
        </tbody></table>
      </article>
      <article className="activity-card"><div className="card-heading"><div><span>RECENT ACTIVITY</span><h3>Record trail</h3></div></div>{['Correction accepted for F-10804','2,140 records validated','Approval reference added','Offline upload synchronised'].map((x,i)=><div className="activity" key={x}><i><Icon name={i===1?'check':i===3?'sync':'file'} size={14}/></i><div><strong>{x}</strong><span>{['Central Institute · 18 min','Western Institute · 42 min','National College · 1h','Field unit 04 · 2h'][i]}</span></div></div>)}</article>
    </section>
  </>
}

function Toolbar({ placeholder = 'Search records, IDs or institutions…' }: { placeholder?: string }) {
  return <div className="toolbar"><div className="table-search"><Icon name="search" /><input placeholder={placeholder} /></div><button><Icon name="filter" />Filters <b>2</b></button><select><option>All statuses</option><option>Needs review</option><option>Validated</option></select><button className="icon-only"><Icon name="dots" /></button></div>
}

function StudentsPage() {
  const [selected, setSelected] = useState<typeof students[number] | null>(null)
  return <>
    <section className="page-intro"><div><span>STUDENT RECORDS</span><h2>Trace every enrolment to the individual.</h2><p>Search identity status, programme history, seat category and all recorded changes.</p></div><Button icon="upload">Add records</Button></section>
    <section className="table-card"><Toolbar /><div className="table-meta"><span>2,481,902 records</span><span>Last synchronised 12 minutes ago</span></div><div className="table-wrap"><table><thead><tr><th><input type="checkbox" /></th><th>Student</th><th>Institution</th><th>Programme</th><th>APAAR status</th><th>Seat category</th><th>Validation</th><th /></tr></thead><tbody>{students.map(s=><tr key={s.id} onClick={()=>setSelected(s)}><td><input type="checkbox" onClick={e=>e.stopPropagation()} /></td><td><div className="student-cell"><i>{s.name.split(' ').map(n=>n[0]).join('')}</i><div><strong>{s.name}</strong><span>{s.id}</span></div></div></td><td>{s.inst}</td><td>{s.programme}</td><td><Status tone={s.apaar==='Linked'?'good':s.apaar==='Pending'?'warn':'neutral'}>{s.apaar}</Status></td><td>{s.category}</td><td><Status tone={s.status==='Validated'?'good':s.status==='Review'?'warn':'bad'}>{s.status}</Status></td><td><Icon name="chevron" size={15}/></td></tr>)}</tbody></table></div><div className="pagination"><span>Showing 1–5 of 2,481,902</span><div><button>Previous</button><b>1</b><button>2</button><button>3</button><button>Next</button></div></div></section>
    {selected && <div className="drawer-backdrop" onClick={()=>setSelected(null)}><aside className="record-drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><span>STUDENT PROFILE</span><button onClick={()=>setSelected(null)}><Icon name="close"/></button></div><div className="profile-title"><i>{selected.name.split(' ').map(n=>n[0]).join('')}</i><div><h2>{selected.name}</h2><span>{selected.id}</span></div></div><div className="profile-status"><Status tone="good">Active enrolment</Status><Status tone={selected.apaar==='Linked'?'good':'warn'}>APAAR {selected.apaar}</Status></div><div className="detail-grid"><label>Institution<strong>{selected.inst}</strong></label><label>Programme<strong>{selected.programme}</strong></label><label>Academic year<strong>2024–25</strong></label><label>Seat category<strong>{selected.category}</strong></label></div><h3>Enrolment history</h3><div className="timeline"><div><i/><span>12 Feb 2025</span><strong>Validation completed</strong><p>All applicable identity and intake checks rerun.</p></div><div><i/><span>08 Feb 2025</span><strong>Seat category updated</strong><p>Changed by institutional administrator.</p></div><div><i/><span>02 Aug 2024</span><strong>Enrolment recorded</strong><p>Submitted in batch WIT-2408-04.</p></div></div><Button variant="secondary">View full change history</Button></aside></div>}
  </>
}

function UploadPage({ setPage }: { setPage: (p: Page) => void }) {
  const [step, setStep] = useState(2)
  const steps = ['Choose file','Map columns','Validate rows','Review & submit']
  return <section className="upload-page">
    <div className="page-intro"><div><span>GUIDED IMPORT</span><h2>Bring student records into I2I.</h2><p>Map once, validate before submission and resolve row-level issues without leaving the workflow.</p></div><Status tone="neutral">Draft auto-saved</Status></div>
    <div className="stepper">{steps.map((s,i)=><button key={s} className={i+1===step?'active':i+1<step?'complete':''} onClick={()=>setStep(i+1)}><i>{i+1<step?<Icon name="check" size={14}/>:i+1}</i><span><small>STEP 0{i+1}</small>{s}</span></button>)}</div>
    {step===1 && <div className="upload-zone"><div className="upload-icon"><Icon name="upload" size={28}/></div><h3>Drop your CSV or Excel file here</h3><p>Up to 25 MB · .csv, .xlsx or .xls</p><Button onClick={()=>setStep(2)}>Choose a file</Button><span>Use the I2I template for the smoothest import.</span></div>}
    {step===2 && <div className="mapping-card"><div className="mapping-head"><div><Status tone="good">student_records_feb.xlsx</Status><h3>Map file columns to I2I fields</h3></div><span>18,420 rows · 14 columns</span></div><div className="mapping-list"><div className="map-title"><span>SOURCE COLUMN</span><span>I2I FIELD</span><span>SAMPLE VALUE</span></div>{[['student_name','Full name','Aarav Mehta'],['apaar_reference','APAAR reference','•••• 4819'],['programme_code','Programme code','CS-UG-01'],['admission_year','Academic year','2024–25'],['seat_category','Seat category','General']].map((r,i)=><div className="map-row" key={r[0]}><code>{r[0]}</code><Icon name="arrow" size={16}/><select defaultValue={r[1]}><option>{r[1]}</option><option>Do not import</option></select><span>{r[2]}</span><Status tone={i===4?'warn':'good'}>{i===4?'Review':'Mapped'}</Status></div>)}</div><div className="wizard-actions"><Button variant="ghost" onClick={()=>setStep(1)}>Back</Button><Button onClick={()=>setStep(3)} icon="arrow">Validate 18,420 rows</Button></div></div>}
    {step===3 && <div className="validation-card"><div className="validation-summary"><div><span>VALIDATION RESULT</span><strong>18,284</strong><small>Ready to submit</small></div><div className="warn"><span>NEEDS REVIEW</span><strong>124</strong><small>Missing or invalid values</small></div><div className="bad"><span>DUPLICATES</span><strong>12</strong><small>Potential record matches</small></div></div><Toolbar placeholder="Search row errors…"/><table><thead><tr><th>Row</th><th>Student</th><th>Issue</th><th>Source value</th><th>Required correction</th></tr></thead><tbody>{[['184','Diya Nair','Missing APAAR status','—','Provide status or mark unavailable'],['892','Arjun Rao','Potential duplicate','ARJUN RAO · 2005-04-12','Review matched record'],['1,204','Sara Khan','Invalid programme code','CSE_01','Use an approved programme code']].map((r,i)=><tr key={r[0]}><td>{r[0]}</td><td><strong>{r[1]}</strong></td><td><Status tone={i===1?'bad':'warn'}>{r[2]}</Status></td><td><code>{r[3]}</code></td><td>{r[4]}</td></tr>)}</tbody></table><div className="wizard-actions"><Button variant="ghost" onClick={()=>setStep(2)}>Back to mapping</Button><Button onClick={()=>setStep(4)} icon="arrow">Continue with valid rows</Button></div></div>}
    {step===4 && <div className="submission-result"><i><Icon name="check" size={30}/></i><span>SUBMISSION COMPLETE</span><h2>18,284 records added to the queue.</h2><p>Validation results are preserved. Reconciliation checks will update as each record is processed.</p><div><b>Batch WIT-2502-17</b><Status tone="info">Processing</Status></div><Button onClick={()=>setPage('reconcile')} icon="arrow">Open reconciliation</Button></div>}
  </section>
}

function ReconcilePage({ setPage }: { setPage: (p: Page) => void }) {
  const [changed, setChanged] = useState(false)
  return <>
    <section className="page-intro"><div><span>RECONCILIATION WORKSPACE</span><h2>One discrepancy, fully explained.</h2><p>Compare the student-level register, reported totals and applicable approved intake.</p></div><div className="intro-actions"><Button variant="secondary">AY 2024–25 <Icon name="chevron" size={14}/></Button><Button>Run checks</Button></div></section>
    <section className="reconcile-shell">
      <div className="reconcile-header"><div><Status tone="bad">High priority</Status><span>FINDING F-10882</span></div><div><span>Last run 17 Feb, 10:42</span><button><Icon name="dots"/></button></div></div>
      <div className="reconcile-title"><div><h2>Reported enrolment exceeds approved intake</h2><p>Western Institute of Technology · B.Tech Computer Science · AY 2024–25</p></div><div className="reconcile-score"><span>RECONCILIATION GAP</span><strong>{changed ? '+05' : '+06'}</strong><small>student records</small></div></div>
      <div className="three-way">
        <div className="reconcile-column identity-col"><div className="column-title"><span>01</span><div><small>STUDENT-LEVEL</small><h3>Enrolment register</h3></div></div><strong>{changed ? '125' : '126'}</strong><p>Active student records after validation</p><div className="mini-list"><span><i className="good"/>124 identity-linked</span><span><i className="warn"/>2 identity status pending</span><span><i/>0 unresolved duplicates</span></div><button onClick={()=>setChanged(!changed)}>{changed?'Restore Aarav’s record':'Mark 1 record withdrawn'} <Icon name="arrow" size={14}/></button></div>
        <div className="comparison-rail"><span>MATCHED</span><i/><b className={changed?'almost':''}>{changed?'−1':'='}</b><i/><span>CHECKED</span></div>
        <div className="reconcile-column report-col"><div className="column-title"><span>02</span><div><small>INSTITUTION-REPORTED</small><h3>Enrolment total</h3></div></div><strong>126</strong><p>Submitted on 12 February 2025</p><div className="mini-list"><span>Male students <b>72</b></span><span>Female students <b>54</b></span><span>Total <b>126</b></span></div><button>View submitted return <Icon name="arrow" size={14}/></button></div>
        <div className="comparison-rail gap"><span>EXCEEDS</span><i/><b>+{changed?'05':'06'}</b><i/><span>APPLICABLE</span></div>
        <div className="reconcile-column approval-col"><div className="column-title"><span>03</span><div><small>APPROVAL CONTEXT</small><h3>Approved intake</h3></div></div><strong>120</strong><p>Applicable programme intake for AY</p><div className="mini-list"><span>Base intake <b>120</b></span><span>Additional permission <b>0</b></span><span>Reference <b>1-4438…</b></span></div><button>Open approval record <Icon name="arrow" size={14}/></button></div>
      </div>
      <div className="explanation-panel"><div><Icon name="reconcile"/><div><span>WHAT I2I FOUND</span><h3>{changed?'One student-level change affects two checks.':'Six more active student records than the applicable intake.'}</h3></div></div><p>{changed?'Aarav Mehta was marked withdrawn. The student register is now 125, while the reported total remains 126. Update the institutional return and verify permission for 5 remaining seats.':'No additional permission is attached for this programme and year. Confirm an approval document exists, or correct the student register and institutional return.'}</p><div className="affected"><span>AFFECTED CHECKS</span><Status tone={changed?'warn':'bad'}>Student total {changed?'updated':'mismatch'}</Status><Status tone="bad">Intake threshold exceeded</Status><Status tone={changed?'warn':'good'}>Reported total {changed?'out of sync':'matched'}</Status></div><Button onClick={()=>setPage('findings')} icon="arrow">Open finding & request correction</Button></div>
    </section>
  </>
}

function FindingsPage() {
  const [active, setActive] = useState(0)
  const [resolved, setResolved] = useState(false)
  return <>
    <section className="page-intro"><div><span>REVIEW QUEUE</span><h2>Resolve discrepancies with evidence.</h2><p>Keep the finding, response, decision and correction history in one auditable thread.</p></div><Button variant="secondary">Export queue</Button></section>
    <div className="review-layout">
      <aside className="finding-list"><Toolbar placeholder="Search findings…"/>{findings.map((f,i)=><button key={f.id} className={active===i?'active':''} onClick={()=>setActive(i)}><div><Status tone={f.level==='High'?'bad':'warn'}>{f.level}</Status><span>{f.id}</span><time>{f.age}</time></div><strong>{f.title}</strong><p>{f.place}</p><b>{f.value}</b></button>)}</aside>
      <section className="review-detail">
        <div className="review-head"><div><span>{findings[active].id} · OPEN FINDING</span><h2>{findings[active].title}</h2><p>{findings[active].place}</p></div><Status tone={resolved?'good':'bad'}>{resolved?'Resolved':'Response due in 4 days'}</Status></div>
        {active===1 ? <div className="duplicate-compare"><div className="compare-head"><span>POTENTIAL DUPLICATE COMPARISON</span><b>92% match confidence</b></div><div className="record-compare"><div><small>RECORD A · ACTIVE</small><h3>Arjun Rao</h3><dl><dt>Date of birth</dt><dd>12 Apr 2005</dd><dt>APAAR reference</dt><dd>•••• 9281</dd><dt>Programme</dt><dd>MBA</dd><dt>Mobile</dt><dd>•••• 4412</dd></dl></div><span className="vs">VS</span><div><small>RECORD B · UPLOADED</small><h3>Arjun K. Rao</h3><dl><dt>Date of birth</dt><dd>12 Apr 2005</dd><dt>APAAR reference</dt><dd>•••• 9281</dd><dt>Programme</dt><dd>MBA</dd><dt>Mobile</dt><dd>•••• 4412</dd></dl></div></div><div className="decision-bar"><p>Identity reference, date of birth and mobile suffix match.</p><Button variant="secondary">Keep separate</Button><Button onClick={()=>setResolved(true)}>Merge records</Button></div></div> :
        <><div className="evidence-block"><div className="evidence-title"><span>DISCREPANCY DETAIL</span><button>View reconciliation <Icon name="arrow" size={14}/></button></div><div className="evidence-numbers"><div><span>Student records</span><strong>126</strong></div><i>−</i><div><span>Applicable intake</span><strong>120</strong></div><i>=</i><div className="bad"><span>Difference</span><strong>+06</strong></div></div></div><div className="response-block"><div className="block-heading"><span>INSTITUTION RESPONSE</span><Status tone="info">Received 16 Feb</Status></div><p>Six students were admitted under an additional intake permission issued for AY 2024–25. The approval reference is attached for review.</p><div className="attachment"><Icon name="file"/><div><strong>additional_permission_2024.pdf</strong><span>PDF · 1.8 MB · Uploaded by N. Sharma</span></div><button>View</button></div></div></>}
        <div className="resolution-history"><span>RESOLUTION HISTORY</span><div><i/><time>17 Feb · 09:42</time><strong>Finding assigned to regional reviewer</strong><p>Priority escalated based on intake threshold.</p></div><div><i/><time>16 Feb · 16:08</time><strong>Institution submitted a response</strong><p>Supporting approval document attached.</p></div><div><i/><time>12 Feb · 11:20</time><strong>Finding created by reconciliation check</strong></div></div>
        <div className="review-actions"><Button variant="ghost">Request more evidence</Button><Button variant="secondary">Return for correction</Button><Button onClick={()=>setResolved(true)}>{resolved?'Decision recorded':'Accept & resolve'}</Button></div>
      </section>
    </div>
  </>
}

function ApprovalsPage() {
  return <><section className="page-intro"><div><span>APPROVAL REGISTER</span><h2>Intake context, without ambiguity.</h2><p>Programme-wise intake, additional permissions and supporting references.</p></div><Button>Add approval record</Button></section><section className="table-card"><Toolbar placeholder="Search institution, programme or reference…"/><div className="table-wrap"><table><thead><tr><th>Institution / programme</th><th>Academic year</th><th>Approved intake</th><th>Additional permission</th><th>Approval reference</th><th>Documents</th><th>Status</th></tr></thead><tbody>{[['Western Institute of Technology','B.Tech · CSE','2024–25','120','—','1-44382-WIT-24','2','Applicable'],['Eastern School of Technology','MBA','2024–25','180','+30','1-53290-EST-24','3','Applicable'],['National College of Engineering','B.Tech · Civil','2024–25','60','—','1-67281-NCE-24','1','Applicable'],['Central Institute of Design','B.Des · Product','2023–24','40','+10','1-29401-CID-23','2','Archived']].map(r=><tr key={r[5]}><td><strong>{r[0]}</strong><span className="subcell">{r[1]}</span></td><td>{r[2]}</td><td><strong>{r[3]}</strong></td><td>{r[4]}</td><td><code>{r[5]}</code></td><td><button className="document-link"><Icon name="file" size={15}/>{r[6]} files</button></td><td><Status tone={r[7]==='Applicable'?'good':'neutral'}>{r[7]}</Status></td></tr>)}</tbody></table></div></section></>
}

function SyncPage() {
  const [syncing, setSyncing] = useState(false)
  return <><section className="page-intro"><div><span>OFFLINE QUEUE</span><h2>Keep working when connectivity can’t.</h2><p>Review locally saved records, upload progress and conflicts before they affect central totals.</p></div><Button onClick={()=>{setSyncing(true);setTimeout(()=>setSyncing(false),1200)}} icon="sync">{syncing?'Synchronising…':'Sync all now'}</Button></section><section className="sync-banner"><div><i className={syncing?'spin':''}><Icon name="sync" size={22}/></i><div><strong>{syncing?'Synchronising 128 records':'Last synchronised 14 minutes ago'}</strong><span>Field device FDU-WIT-04 · Secure connection available</span></div></div><Status tone="good">Online</Status></section><section className="sync-grid">{[['Locally saved','128','Ready for upload','info'],['Pending upload','34','Waiting in queue','warn'],['Synchronised','2,918','Since 01 February','good'],['Failed','3','Can be retried','bad'],['Conflicts','7','Require review','bad']].map(x=><div className="sync-stat" key={x[0]}><span>{x[0]}</span><strong>{x[1]}</strong><Status tone={x[3] as 'good'}>{x[2]}</Status></div>)}</section><section className="table-card"><div className="card-heading padded"><div><span>REQUIRES ATTENTION</span><h3>Upload conflicts & failures</h3></div><button>Retry all failures</button></div><table><thead><tr><th>Record</th><th>Local change</th><th>Central record</th><th>Conflict</th><th>Saved</th><th>Action</th></tr></thead><tbody>{[['I2I-2401857 · Diya Nair','Programme changed','Validation completed','Newer central version','12 min ago'],['I2I-2402204 · Ishaan Sen','Record created','Possible match exists','Potential duplicate','28 min ago'],['Batch FDU-1702-03','42 new records','—','Connection interrupted','1h ago']].map((r,i)=><tr key={r[0]}><td><strong>{r[0]}</strong></td><td>{r[1]}</td><td>{r[2]}</td><td><Status tone={i===2?'warn':'bad'}>{r[3]}</Status></td><td>{r[4]}</td><td><button className="text-button">{i===2?'Retry':'Review conflict'} →</button></td></tr>)}</tbody></table></section></>
}

function VerificationPage() {
  const [result, setResult] = useState(false)
  return <><section className="page-intro"><div><span>AUTHORISED VERIFICATION</span><h2>Confirm enrolment with purpose.</h2><p>Submit a purpose-bound request. Results reveal only the minimum necessary record status.</p></div></section><div className="verification-layout"><section className="verify-form"><span>NEW VERIFICATION REQUEST</span><h3>Student & request details</h3><label>Student I2I reference<input defaultValue="I2I-2401856"/></label><label>Academic year<select><option>2024–25</option></select></label><label>Verification purpose<select><option>Scholarship eligibility review</option><option>Academic record verification</option></select></label><label>Authorisation reference<input placeholder="Enter reference from authorising document"/></label><label className="consent"><input type="checkbox" defaultChecked/><span>I confirm this request is authorised and limited to the stated purpose.</span></label><Button onClick={()=>setResult(true)} icon="arrow">Run verification</Button></section><section className={`verify-result ${result?'visible':''}`}>{result?<><div className="result-seal"><Icon name="check" size={28}/></div><span>VERIFICATION RESULT · VR-2025-00841</span><h2>Active enrolment confirmed</h2><p>The supplied student reference is associated with an active enrolment for the selected academic year.</p><dl><dt>Student</dt><dd>Aarav Mehta</dd><dt>Institution</dt><dd>Western Institute of Technology</dd><dt>Programme</dt><dd>B.Tech · Computer Science</dd><dt>Academic year</dt><dd>2024–25</dd><dt>Checked at</dt><dd>17 Feb 2025 · 11:08</dd></dl><div className="privacy-note">No identity number or contact information is included in this result.</div><Button variant="secondary">Download signed result</Button></>:<div className="empty-result"><Icon name="check" size={32}/><h3>Verification result</h3><p>Complete the authorised request to see a minimal, purpose-bound result here.</p></div>}</section></div></>
}

function ReportsPage() {
  const [tab, setTab] = useState('Reports')
  return <><section className="page-intro"><div><span>REPORTING & COMMUNICATION</span><h2>Turn oversight into action.</h2><p>Generate enrolment and intake reports, review audit history and manage notifications.</p></div><Button>Generate report</Button></section><div className="tabs">{['Reports','Audit history','Notifications','SMS settings'].map(t=><button className={tab===t?'active':''} onClick={()=>setTab(t)} key={t}>{t}{t==='Notifications'&&<b>4</b>}</button>)}</div>{tab==='Reports'&&<div className="report-grid">{[['chart','Enrolment summary','Institution, programme, category and year-wise student totals.'],['reconcile','Intake comparison','Reported enrolment against applicable approved intake.'],['flag','Discrepancy report','Open, resolved and ageing findings with decision details.'],['file','Audit extract','Record changes, reviewer actions and synchronisation events.']].map(r=><article key={r[1]}><Icon name={r[0]} size={22}/><h3>{r[1]}</h3><p>{r[2]}</p><div><Status tone="neutral">XLSX · CSV · PDF</Status><button>Configure →</button></div></article>)}</div>}{tab==='Audit history'&&<section className="table-card"><Toolbar placeholder="Search user or action…"/><table><thead><tr><th>Timestamp</th><th>User</th><th>Action</th><th>Record</th><th>Source</th></tr></thead><tbody>{[['17 Feb · 10:42','Ananya Menon','Reconciliation rerun','F-10882','Web'],['17 Feb · 09:18','N. Sharma','Evidence attached','F-10882','Web'],['16 Feb · 16:08','Field unit 04','Records synchronised','Batch FDU-169','Offline sync']].map(r=><tr key={r[0]}>{r.map((x,i)=><td key={x}>{i===1?<strong>{x}</strong>:x}</td>)}</tr>)}</tbody></table></section>}{tab==='Notifications'&&<div className="notification-center">{['Correction request due in 4 days','Batch WIT-2502-17 validation complete','Additional permission awaiting review','7 offline conflicts require attention'].map((n,i)=><div key={n}><i className={i>1?'warn':''}><Icon name={i===1?'check':'bell'} size={17}/></i><div><strong>{n}</strong><p>{['Finding F-10882 · Western Institute','18,284 records are ready for reconciliation','Reference 1-53290-EST-24','Field device FDU-WIT-04'][i]}</p></div><time>{['12 min','42 min','2 h','5 h'][i]}</time><button><Icon name="dots"/></button></div>)}</div>}{tab==='SMS settings'&&<section className="settings-card"><div><span>MOBILE & OTP SETTINGS</span><h3>Secure notifications</h3><p>Manage the registered mobile number used for sign-in OTP and selected workflow alerts.</p></div><label>Registered mobile number<div className="phone-input"><span>+91</span><input defaultValue="98••• ••412"/></div></label><label>OTP preference<select><option>SMS to registered mobile</option></select></label><div className="toggle-row"><div><strong>Finding due-date alerts</strong><span>Receive SMS 48 hours before a response is due.</span></div><input type="checkbox" defaultChecked/></div><div className="toggle-row"><div><strong>Sync failure alerts</strong><span>Receive SMS after three failed upload attempts.</span></div><input type="checkbox" defaultChecked/></div><Button>Save settings</Button></section>}</>
}

function Chatbot({ open, setOpen }: { open: boolean; setOpen: (v: boolean) => void }) {
  const [messages, setMessages] = useState<string[]>([])
  const [input, setInput] = useState('')
  const send = (text: string) => { if (text.trim()) { setMessages([...messages, text]); setInput('') } }
  return <><button className="bot-launcher" onClick={()=>setOpen(!open)}><Icon name={open?'close':'bot'} size={21}/><span>{open?'Close':'I2I Bot'}</span><i/></button>{open&&<aside className="bot-panel"><div className="bot-head"><div><i><Icon name="bot"/></i><div><strong>I2I Bot</strong><span>Workspace assistant</span></div></div><button onClick={()=>setOpen(false)}><Icon name="close"/></button></div><div className="chat-body"><div className="bot-message">Hello, Ananya. I can explain findings, locate records or help with I2I workflows.</div><span className="quick-title">QUICK QUESTIONS</span>{['Explain finding F-10882','What changed after the last upload?','Show pending institution responses'].map(q=><button className="quick-question" key={q} onClick={()=>send(q)}>{q}<Icon name="arrow" size={14}/></button>)}{messages.map((m,i)=><div key={i} className="chat-exchange"><div className="user-message">{m}</div><div className="bot-message">{m.includes('F-10882')?'F-10882 was created because 126 active student records and the reported total both exceed the applicable intake of 120. No additional permission is currently attached. The required correction is to add valid approval evidence or correct 6 affected records.':'I found the relevant workspace information. Open the linked records to review the supporting detail and activity history.'}</div></div>)}</div><form className="chat-input" onSubmit={e=>{e.preventDefault();send(input)}}><input value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask about records or findings…"/><button><Icon name="arrow"/></button></form><div className="bot-foot">Responses use demonstration workspace data.</div></aside>}</>
}

function Notifications({ onClose }: { onClose: () => void }) {
  return <div className="popover notifications-pop"><div className="popover-head"><strong>Notifications</strong><button onClick={onClose}><Icon name="close"/></button></div>{['Correction request due soon','Validation completed','New institution response'].map((n,i)=><button key={n}><i><Icon name={i===1?'check':'bell'} size={15}/></i><div><strong>{n}</strong><span>{['F-10882 · Due in 4 days','Batch WIT-2502-17','Finding F-10879 · 2h ago'][i]}</span></div></button>)}<button className="view-all">View notification centre</button></div>
}

function Workspace({ role, onLogout }: { role: Role; onLogout: () => void }) {
  const [page, setPage] = useState<Page>(role === 'Authorised Verifier' ? 'verification' : 'dashboard')
  const [menu, setMenu] = useState(false)
  const [bot, setBot] = useState(false)
  const [notifs, setNotifs] = useState(false)
  const content = useMemo(() => {
    switch(page) {
      case 'dashboard': return <Dashboard role={role} setPage={setPage}/>
      case 'students': return <StudentsPage/>
      case 'upload': return <UploadPage setPage={setPage}/>
      case 'reconcile': return <ReconcilePage setPage={setPage}/>
      case 'findings': return <FindingsPage/>
      case 'approvals': return <ApprovalsPage/>
      case 'sync': return <SyncPage/>
      case 'verification': return <VerificationPage/>
      case 'reports': return <ReportsPage/>
    }
  }, [page, role])
  return <div className="app-shell"><Sidebar page={page} setPage={setPage} role={role} onLogout={onLogout} open={menu} onClose={()=>setMenu(false)}/><main className="workspace"><Topbar page={page} onMenu={()=>setMenu(true)} onNotify={()=>setNotifs(!notifs)}/><div className="workspace-content">{content}</div></main>{notifs&&<Notifications onClose={()=>setNotifs(false)}/>}<Chatbot open={bot} setOpen={setBot}/></div>
}

export default function App() {
  const [screen, setScreen] = useState<'landing'|'login'|'app'>('landing')
  const [role, setRole] = useState<Role>('AICTE Officer')
  if (screen === 'landing') return <Landing onLogin={()=>setScreen('login')}/>
  if (screen === 'login') return <Login onBack={()=>setScreen('landing')} onSubmit={(r)=>{setRole(r);setScreen('app')}}/>
  return <Workspace role={role} onLogout={()=>setScreen('landing')}/>
}
